#!bin/sh
#java -cp uinumtpfilequeue.jar:uinproto_smpp.jar:smscsim.jar:uinmsg.jar:uincfg.jar:uinlog.jar:uinproto.jar -Xms12m -Xmx300m com.logica.smscsim.Simulator $1

java -cp uinumtpfilequeue.jar:uinproto_smpp.jar:smscsim.jar:uinmsg.jar:uincfg.jar:uinlog.jar:log4j-1.2.16.jar:uinproto.jar -Xms12m -Xmx300m com.logica.smscsim.Simulator $1
