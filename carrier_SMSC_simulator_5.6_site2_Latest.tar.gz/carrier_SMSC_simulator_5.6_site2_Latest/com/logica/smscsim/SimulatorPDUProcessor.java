package com.logica.smscsim;

import com.logica.smpp.SmppObject;
import com.logica.smpp.debug.*;
import com.logica.smpp.pdu.*;
import com.logica.smpp.*;
import com.logica.smscsim.util.Record;
import com.logica.smscsim.util.Table;
import java.sql.Timestamp;
import java.util.ArrayList;

public class SimulatorPDUProcessor extends PDUProcessor {

    public SimulatorPDUProcessor(SMSCSession smscsession, ShortMessageStore shortmessagestore, Table table) {
        session = null;
        deliveryInfoSender = null;
        users = null;
        bound = false;
        systemId = null;
        displayInfo = false;
        delayReplyTime = 0L;
        event = SmppObject.getEvent();
        session = smscsession;
        users = table;
        trackingIdSufix = "Smsc";
    }

    public void clientRequest(Request request) {
        int j = request.getCommandId();
        try {            
            if (!bound) {
                if (j == Data.BIND_TRANSMITTER || j == Data.BIND_RECEIVER || j == Data.BIND_TRANSCEIVER) {
                    int i = checkIdentity((BindRequest)request);
                    display(Thread.currentThread().getName() + " BIND Request : " + i);
                    if (i == 0) {
                        BindResponse bindresponse = (BindResponse)request.getResponse();
                        bindresponse.setSystemId("VeriSign");
                        bound = true;
                        display(" useFileQueueWriterForDR : " + useFileQueueWriterForDR + " useFileQueueReaderForDR:" + useFileQueueReaderForDR);
                        if (useFileQueueWriterForDR) {
                        	deliveryInfoSender.createDRFileWriter();
                        }
                        if (useFileQueueReaderForDR) {
                        	deliveryInfoSender.createDRFileReader(this);
                        }
                        System.err.println("Starting DelvResponseWorker threads : " + numOfRespWorkerThreads);
                        for (int k = 0 ; k < numOfRespWorkerThreads ; k++){
                            new DelvResponseWorker(this).start();
                        }
                        serverResponse(bindresponse);
                    } else {
                        Response response = request.getResponse();
                        response.setCommandStatus(i);
                        serverResponse(response);
                        session.stop();
                    }
                } else {
                    if (request.canResponse()) {
                        Response response1 = request.getResponse();
                        response1.setCommandStatus(4);
                        serverResponse(response1);
                    }
                    session.stop();
                }
            } else if (request.canResponse()) {
                switch (j) {
	                case Data.SUBMIT_SM:
	                    synchronized (objForSync) {                    	
	                        acceptedPdu.add(request);
	                        display(Thread.currentThread().getName() + " SUBMIT_SM Request : " + request.debugString());
	                    }
	                    break;
	                case Data.ENQUIRE_LINK:
		                EnquireLink enq = (EnquireLink)request;
		                EnquireLinkResp enqresp = (EnquireLinkResp)enq.getResponse();
		                display(Thread.currentThread().getName() + " Received EnquireLink Request event.. sending Enquirelink response : " + enqresp.debugString());
		                serverResponse(enqresp);
		                break;
	                case Data.UNBIND:
		                Unbind unbind = (Unbind)request;
		                UnbindResp unbindResp = (UnbindResp)unbind.getResponse();
		                display(Thread.currentThread().getName() + " Received Unbind Request event..sending unbind response" + unbindResp.debugString());
		                serverResponse(unbindResp);
		                break;
                }
                if (j == 6)
                    session.stop();
            }
        } catch(WrongLengthOfStringException wronglengthofstringexception) {
            event.write(wronglengthofstringexception, "");
        }
    }

    public void clientResponse(Response response) {
        display( Thread.currentThread().getName()  + " Client Response: " + response.debugString());
    }

    public void serverRequest(Request request) {    	
        session.send(request);
    }

    public void serverResponse(Response response) {        
        session.send(response);
    }
    
    public void setUseFileQueueWriterForDR(boolean useFileQueueWriterForDR) {
    	this.useFileQueueWriterForDR = useFileQueueWriterForDR;
    }

    public void setUseFileQueueReaderForDR(boolean useFileQueueReaderForDR) {
    	this.useFileQueueReaderForDR = useFileQueueReaderForDR;
    }

    private int checkIdentity(BindRequest bindrequest) {
        byte byte0 = 0;
        Record record = users.find("name", bindrequest.getSystemId());
        if (record != null) {
            String pwd = record.getValue("password");
            String timeout = record.getValue("timeout");
            String numofthreads = record.getValue("numofthreads");

            if (pwd != null) {
                if(!bindrequest.getPassword().equals(pwd)) {
                    byte0 = 14;
                    display(Thread.currentThread().getName() + " Not authenticated " + bindrequest.getSystemId() + " -- invalid password");
                } else {
                    systemId = bindrequest.getSystemId();
                    display(Thread.currentThread().getName() + " Authenticated " + systemId + " **timeout: " + timeout + " numOfRespWorkerThreads : " + numofthreads);
                    if (timeout != null) {
                    	delayReplyTime = Integer.parseInt(timeout);
                    }                	
                	if (numofthreads != null) {
                		numOfRespWorkerThreads = Integer.parseInt(numofthreads);
                    }
                }
            } else {
                byte0 = 14;
                display(Thread.currentThread().getName() + " Not authenticated " + systemId + " -- no password for user.");
            }
        } else {
            byte0 = 15;
            display(Thread.currentThread().getName() + " Not authenticated " + bindrequest.getSystemId() + " -- user not found");
        }
        return byte0;
    }

    private String assignMessageId() {
        StringBuffer sb = new StringBuffer(trackingIdSufix);
        sb.append((int) (Math.random()* 999999999));
        return sb.toString();
    }

    public SMSCSession getSession() {
        return session;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setDisplayInfo(boolean flag) {
        displayInfo = flag;
    }

    public boolean getDisplayInfo() {
        return displayInfo;
    }

    public void setDeliveryInfoSender(DeliveryInfoSender deliveryinfosender) {
        deliveryInfoSender = deliveryinfosender;
    }
    
    public void setTrackingIdSufix(String trackingId) {
    	trackingIdSufix = trackingId;
	}
	public String getTrackingIdSufix() {
    	return trackingIdSufix;
	}

    public void setSleepTimeToSendDR(long sleepTime) {
    	sleepTimeToSendDR = sleepTime;
    }

    public void display(String s) {
        if (getDisplayInfo()) {
            String s1 = getSystemId();
            System.err.println((new Timestamp(System.currentTimeMillis())).toString() + " [" + s1 + "] " + s);
        }
    }

    public void setCommandStatus (int commandStatus) {
    	this.commandStatus = commandStatus;
    }
    
    private SMSCSession session;
    private DeliveryInfoSender deliveryInfoSender;
    private Table users;
    private boolean bound;
    private String systemId = "";
    private boolean displayInfo;
    private long delayReplyTime;    
    private Event event;
    public Object objForSync = new Object();
    private ArrayList acceptedPdu = new ArrayList();
    private int numOfRespWorkerThreads = 10;
    private String trackingIdSufix;
    private int commandStatus;
    private boolean useFileQueueWriterForDR;
    private boolean useFileQueueReaderForDR;
    private long sleepTimeToSendDR;
    
	private class DelvResponseWorker extends Thread {

    	private PDUProcessor pduProcessor;
    	DelvResponseWorker(PDUProcessor pduProcessor) {
    		this.pduProcessor = pduProcessor;
    	}

		public void run() {
            while (true) {
                try {
                    if (acceptedPdu.size() == 0 ) {
                        Thread.sleep(300);
                    } else {
                    	Request req = null;
                        synchronized(objForSync) {
                            if (acceptedPdu.size() > 0 ) {
                                req = (Request)acceptedPdu.remove(0);
                            }
                        }
                        if(req != null) {
                            if(acceptedPdu.size() > 3000) {
                                System.err.println("SUBMIT_SM Arraylist size: " + acceptedPdu.size());
                            }
                            Thread.sleep(delayReplyTime);
                            long timeStamp = System.currentTimeMillis();
                            Response response2 = req.getResponse();
                            SubmitSMResp submitsmresp = (SubmitSMResp)response2;
                            submitsmresp.setMessageId(assignMessageId());
                            if (commandStatus > 0) {
                            	submitsmresp.setCommandStatus(commandStatus);
                            }
                            display(Thread.currentThread().getName() + " SUBMIT_SM Response : " + submitsmresp.debugString());
                            serverResponse(submitsmresp);
                            display(Thread.currentThread().getName() + " Time taken to process the SUBMIT_SM response : " + (System.currentTimeMillis() - timeStamp));                            
                            byte byte0 = (byte)(((SubmitSM)req).getRegisteredDelivery() & 3);
                            if ((byte0 == 1 || byte0 == 2) && commandStatus == 0) {
                            	display(Thread.currentThread().getName() + " Sleeping for " + sleepTimeToSendDR + " ms before sending DR");
                            	if (sleepTimeToSendDR > 0) 
                            		Thread.sleep(sleepTimeToSendDR);
                                deliveryInfoSender.submit(pduProcessor, (SubmitSM)req, submitsmresp.getMessageId());	
                            }
                        }
                    }
                } catch (Exception ex) {
                    display(Thread.currentThread().getName() + " While generation response " + ex.toString());
                    System.err.println(ex);
                }
			}
		}
	}
}