package com.logica.smscsim;

import com.logica.smpp.pdu.SubmitSM;
import java.util.Enumeration;
import java.util.Hashtable;
public class ShortMessageStore {

    public ShortMessageStore() {
        messages = new Hashtable();
    }

    public synchronized void submit(SubmitSM submitsm, String s, String s1) {
        messages.put(s, new ShortMessageValue(s1, submitsm));
    }

    public synchronized void cancel(String s) {
        messages.remove(s);
    }

    public synchronized void replace(String s, String s1) {
        ShortMessageValue shortmessagevalue = (ShortMessageValue)messages.get(s);
        if(shortmessagevalue != null)
            shortmessagevalue.shortMessage = s1;
    }

    public synchronized ShortMessageValue getMessage(String s) {
        return (ShortMessageValue)messages.get(s);
    }

    public synchronized void print() {
        if(messages.size() != 0) {
            Enumeration enumeration = messages.keys();
            System.out.println("------------------------------------------------------------------------");
            System.out.println("| Msg Id   |Sender     |ServT|Source address |Dest address   |Message   ");
            System.out.println("------------------------------------------------------------------------");
            ShortMessageValue shortmessagevalue;
            Object obj;
            for(; enumeration.hasMoreElements(); printMessage(obj, shortmessagevalue)) {
                obj = enumeration.nextElement();
                shortmessagevalue = (ShortMessageValue)messages.get(obj);
            }

        } else {
            System.out.println("There is no message in the message store.");
        }
    }

    private void printMessage(Object obj, ShortMessageValue shortmessagevalue) {
        String s = obj.toString();
        String s1 = pad(shortmessagevalue.systemId, 11);
        String s2;
        if(shortmessagevalue.serviceType.equals(""))
            s2 = "null";
        else
            s2 = shortmessagevalue.serviceType;
        s2 = pad(s2, 5);
        String s3 = pad(shortmessagevalue.sourceAddr, 15);
        String s4 = pad(shortmessagevalue.destinationAddr, 15);
        String s5 = shortmessagevalue.shortMessage;
        System.out.println("- " + s + " |" + s1 + "|" + s2 + "|" + s3 + "|" + s4 + "|" + s5);
    }

    private String pad(String s, int i) {
        if(s == null)
            s = "";
        String s1;
        if(s.length() > i) {
            s1 = s.substring(1, i + 1);
        } else {
            int j = i - s.length();
            s1 = s;
            for(int k = 1; k <= j; k++)
                s1 = s1 + " ";

        }
        return s1;
    }
    private Hashtable messages;
}