package com.logica.smscsim;

import com.logica.smpp.debug.FileLog;
import com.logica.smscsim.util.Table;

public class SimulatorPDUProcessorFactory implements PDUProcessorFactory {

    public SimulatorPDUProcessorFactory(PDUProcessorGroup pduprocessorgroup, ShortMessageStore shortmessagestore, DeliveryInfoSender deliveryinfosender, Table table) {
        displayInfo = false;
        procGroup = pduprocessorgroup;
        messageStore = shortmessagestore;
        deliveryInfoSender = deliveryinfosender;
        users = table;
    }

    public PDUProcessor createPDUProcessor(SMSCSession smscsession) {
        SimulatorPDUProcessor simulatorpduprocessor = new SimulatorPDUProcessor(smscsession, messageStore, users);
        simulatorpduprocessor.setDisplayInfo(getDisplayInfo());
        simulatorpduprocessor.setTrackingIdSufix(getTrackingIdSufix());
        simulatorpduprocessor.setSleepTimeToSendDR(getSleepTimeToSendDR());
        simulatorpduprocessor.setGroup(procGroup);
        simulatorpduprocessor.setDeliveryInfoSender(deliveryInfoSender);
        display("new connection accepted");
        return simulatorpduprocessor;
    }

    public void setDisplayInfo(boolean flag) {
        displayInfo = flag;
    }

    public boolean getDisplayInfo() {
        return displayInfo;
    }
    public void setTrackingIdSufix(String trackingId) { 
    	trackingIdSufix = trackingId;
    }
    
    public String getTrackingIdSufix() {
	    	return trackingIdSufix;
    }

    private void display(String s) {
        if(getDisplayInfo())
            System.out.println(FileLog.getLineTimeStamp() + " [sys] " + s);
    }
    
    public void setSleepTimeToSendDR(long sleepTime) {
    	sleepTimeToSendDR = sleepTime;
    }
    
    public long getSleepTimeToSendDR() {
    	return sleepTimeToSendDR;
    }

    private PDUProcessorGroup procGroup;
    private ShortMessageStore messageStore;
    private DeliveryInfoSender deliveryInfoSender;
    private Table users;
    private boolean displayInfo;
    private String trackingIdSufix;
    private long sleepTimeToSendDR;
}