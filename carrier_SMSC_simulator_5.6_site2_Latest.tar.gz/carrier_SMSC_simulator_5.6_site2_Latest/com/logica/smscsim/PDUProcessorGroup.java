package com.logica.smscsim;

import java.util.Vector;

public class PDUProcessorGroup {

    public PDUProcessorGroup() {
        processors = null;
        processors = new Vector();
    }

    public PDUProcessorGroup(int initSize) {
        processors = null;
        processors = new Vector(initSize);
    }

    public void add(PDUProcessor p) {
        synchronized (processors) {
            if(!processors.contains(p))
                processors.add(p);
        }
    }

    public void remove(PDUProcessor p) {
        synchronized (processors) {
            processors.remove(p);
        }
    }

    public int count() {
        int i;
        synchronized (processors) {
            i = processors.size();
        }
        return i;
    }

    public PDUProcessor get(int i) {
        PDUProcessor pduprocessor;
        synchronized(processors) {
            pduprocessor = (PDUProcessor)processors.get(i);
        }
        return pduprocessor;
    }
    private Vector processors;
}