package com.logica.smscsim;

import com.logica.smpp.SmppObject;
import com.logica.smpp.debug.*;
import com.logica.smpp.pdu.DeliverSM;
import com.logica.smpp.pdu.WrongLengthOfStringException;
import com.logica.smpp.pdu.PDU;
import com.logica.smpp.pdu.Request;
import com.logica.smpp.util.ByteBuffer;
import com.logica.smscsim.util.Table;
import com.logica.smpp.pdu.ShortMessage;

import com.unimobile.uin.proto.CmdBind;
import com.unimobile.uin.proto.Command;
import com.unimobile.uin.proto.Refresh;
import com.unimobile.uin.proto.Response;
import com.unimobile.uin.proto.Session;
import com.unimobile.uin.proto.UMTPServer;

import java.io.*;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Random;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Simulator {

	static String propsFilePath = "./smscsim.cfg";

	Random r = new Random();

	private Simulator() {
		try {
			keepRunning = true;
			smscListener = null;
			factory = null;
			processors = null;
			messageStore = null;
			deliveryInfoSender = null;
			users = null;
			displayInfo = true;
			loadProperties();
			FileOutputStream fos = null;


			try {
				Date now = new Date();
				SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
				logfile = properties.getProperty("logfile", "100.txt");
				String logfilename = format1.format(now) + logfile;
				fos = new FileOutputStream(logfilename);
			} catch(IOException ioe) {
				ioe.printStackTrace(System.err);
				display("redirection not possible: "+ioe);
				ioe.printStackTrace();
			}
			PrintStream ps = new PrintStream(fos);
			System.setErr(ps);
			display("Goes into file");
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	private void loadProperties() {

		try {			
			display(" loadProperties() started!.... Reading configuration file " + propsFilePath + "...");
			FileInputStream propsFile = new FileInputStream(propsFilePath);
			properties = new Properties();
			properties.load(propsFile);
			propsFile.close();			
			String loadTestSenderCSVListStr = properties.getProperty("load-test-sender-csv-list", "919845079877");
			StringTokenizer st = new StringTokenizer(loadTestSenderCSVListStr, ",");
			while (st.hasMoreTokens()) {
				loadTestSenderCSVList.add(st.nextToken());
			}
			String loadTestDestinationCSVListStr = properties.getProperty("load-test-destination-csv-list", "999333");
			st = new StringTokenizer(loadTestDestinationCSVListStr, ",");
			while (st.hasMoreTokens()) {
				loadTestDestinationCSVList.add(st.nextToken());
			}

			loadTestSM = properties.getProperty("load-test-short-message", "Test MO 001");
			loadTestRegisteredDelivery = Byte.valueOf(properties.getProperty("load-test-reg-deliv", "0")).byteValue();
			loadTestEsmClass = Byte.valueOf(properties.getProperty("load-test-esm-class", "0")).byteValue();
			loadTestDataCoding = Integer.valueOf(properties.getProperty("load-test-dcs", "0")).intValue();
			loadTestSleepInterval = Integer.valueOf(properties.getProperty("load-test-sleep-interval", "0")).intValue();
			trackingIdSufix = properties.getProperty("tracking-id-sufix", "Smsc");
			sleepTimeToSendDR = Long.parseLong(properties.getProperty("sleep-time-to-send-dr-after-submitsm", "0"));
			noDRWorkerThreads = Integer.valueOf(properties.getProperty("dr-worker-thread-count", "20")).intValue();
			isSSL = new Boolean(properties.getProperty("ssl-enabled", "false")).booleanValue();
			if (isSSL) {
				String smscKeystore = properties.getProperty("smsc-keystore", "smsc_keystore");
				String smscKeystorePassword = properties.getProperty("smsc-keystore-password", "changeit");
				System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
				System.setProperty("javax.net.ssl.keyStore", smscKeystore);
				System.setProperty("javax.net.ssl.keyStorePassword", smscKeystorePassword);
				java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
			}
			useUMTP = new Boolean(properties.getProperty("use-umtp-for-simulator", "false")).booleanValue();
			if (useUMTP) {	        	
				int cmdHandlers = Integer.parseInt(properties.getProperty("umtp-cmdhanders", "1"));	        	
				umtpPort = Integer.parseInt(properties.getProperty("umtp", UMTPServer.DEFAULT_PORT+""));
				display(" Using UMTP For Simulator!!...port : " + umtpPort + " cmdHandlers : " + cmdHandlers);
				m_umtp = new UMTP(umtpPort, cmdHandlers);
			} else {
				display(" Not using UMTP For Simulator !!...");
			}
			DRStatus = properties.getProperty("dr-status", "");
			DRStatusCode = properties.getProperty("dr-status-code", "000");
			msgCommandStatus = properties.getProperty("msg-command-status", "0");
			messageState = properties.getProperty("message-stat");
			userMsgRef = properties.getProperty("user-message-reference");
			networkErrCode = properties.getProperty("network-error-code");
			esm_class = properties.getProperty("esm-class", "4");
			display(" loadProperties() ended!....");
			useWriterForDR = new Boolean(properties.getProperty("use-file-queue-writer-for-drs", "false")).booleanValue();
			useReaderForDR = new Boolean(properties.getProperty("use-file-queue-reader-for-drs", "false")).booleanValue();
			if (useWriterForDR) {
				loadDRFileQueueWriterConfig(properties);
			} 
			if (useReaderForDR) {
				loadDRFileQueueReaderConfig(properties);
			}
			isEnabled = Boolean.parseBoolean(properties.getProperty("tlv-enabled-for-optional-params"));
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	private void loadDRFileQueueWriterConfig(Properties properties) {
		fileQueueDir = properties.getProperty("dr-file-queue-dir-path", "c:\\");
		uniqueID = properties.getProperty("dr-file-queue-writer-unique-id", "DRSimulator");
		commitMsgCount = Integer.parseInt(properties.getProperty("dr-file-queue-commit-msg-count", "5"));
		commitMsgTimeout = Integer.parseInt(properties.getProperty("dr-file-queue-commit-msg-timeout", "200"));
		drFileExt = properties.getProperty("dr-file-queue-file-ext", "drs");
	}

	private void loadDRFileQueueReaderConfig(Properties properties) {
		fileQueueDir = properties.getProperty("dr-file-queue-dir-path", "c:\\");        
		dispatcherThreadCount = Integer.parseInt(properties.getProperty("dr-file-queue-dispatcher-thread-count", "10"));
		drFileExt = properties.getProperty("dr-file-queue-file-ext", "drs");
		fileReaderUniqueId = properties.getProperty("dr-file-queue-reader-unique-id", "DRSimulatorFileReader");
		sleepTimeInterval = Integer.parseInt(properties.getProperty("dr-file-queue-sleep-time-interval", "5"));
	}

	private void refreshProperties() {
		try {
			FileInputStream propsFile = new FileInputStream(propsFilePath);
			properties = new Properties();
			properties.load(propsFile);
			propsFile.close();	
			DRStatus = properties.getProperty("dr-status", "");
			DRStatusCode = properties.getProperty("dr-status-code", "000");
			messageState = properties.getProperty("message-stat");
			userMsgRef = properties.getProperty("user-message-reference");
			networkErrCode = properties.getProperty("network-error-code");
			msgCommandStatus = properties.getProperty("msg-command-status", "0");
			sleepTimeToSendDR = Long.parseLong(properties.getProperty("sleep-time-to-send-dr-after-submitsm", "0"));
			esm_class = properties.getProperty("esm-class", "4");
			display("Refresh Succssful. MsgCommandStatus : " + msgCommandStatus + " DRStatus : " + DRStatus 
					+ " DRStatusCode : " + DRStatusCode + " messageState : " + messageState + " userMsgRef : " + userMsgRef + " networkErrorCode : " 
					+ networkErrCode + " esm-class : " + esm_class + " sleepTimeToSendDR : " + sleepTimeToSendDR);
		} catch (Exception e) {
			e.printStackTrace(System.err);
			display("Refresh failed.... MsgCommandStatus : " + msgCommandStatus + " DRStatus : " + DRStatus 
					+ " DRStatusCode : " + DRStatusCode + " messageState : " + messageState +  " userMsgRef : " + userMsgRef + " networkErrorCode : "
					+ networkErrCode + " esm-class : " + esm_class);
		}
	}    	

	public static void main(String args[]) throws IOException {
		SmppObject.setDebug(debug);
		SmppObject.setEvent(event);
		debug.activate();
		event.activate();
		debug.deactivate(3);
		debug.deactivate(6);
		debug.deactivate(8);
		debug.deactivate(18);
		Simulator simulator = new Simulator();
		simulator.menu();
	}

	protected void menu() throws IOException {
		debug.write("Simulator started");
		keepRunning = true;
		do {
			if(!keepRunning)
				break;
			System.out.println();
			System.out.println("- 1 start simulation");
			System.out.println("- 2 stop simulation");
			System.out.println("- 3 list clients");
			System.out.println("- 4 send message");
			System.out.println("- 5 list messages");
			System.out.println("- 6 reload users file");
			System.out.println((new StringBuffer()).append("- 7 log to screen ").append(displayInfo ? "off" : "on").toString());
			System.out.println("- 8 send MO message from bytes");
			System.out.println("- 9 Start MO load Tester.");
			System.out.println("- 10 Stop MO load Tester.");
			System.out.println("- 11 Submit Binary message body. ");
			System.out.println("- 12 send message To Multi Bind");
			System.out.println("- 13 send PDU Bytes");
			System.out.println("- 0 exit");
			System.out.print("> ");
			int i = -1;
			try {
				String s1 = keyboard.readLine();
				if (s1 != null) {
					i = Integer.parseInt(s1);
				}
			} catch (Exception exception) {
				debug.write((new StringBuffer()).append("exception reading keyboard ").append(exception).toString());
				exception.printStackTrace(System.err);
			}
			switch(i) {
			case 1: // '\001'
				start();
				break;

			case 2: // '\002'
				stop();
				break;

			case 3: // '\003'
				listClients();
				break;

			case 4: // '\004'
				sendMessage();
				break;

			case 5: // '\005'
				messageList();
				break;

			case 6: // '\006'
				reloadUsers();
				break;

			case 7: // '\007'
				logToScreen();
				break;

			case 8: // '\008'
				sendMessageFromBytes();
				break;

			case 9: // '\009'
				startMOLoad();
				break;

			case 10: // '\010'
				stopMOLoad();
				break;

			case 11:
				submitBinaryMessage();
				break;

			case 12:
				sendMessageToMultiBind();
				break;
				
			case 13: // '\004'
				submitBytes();
				break;

				
			case 0: // '\0'
				exit();
				break;

			default:
				System.out.println("Invalid option. Choose between 0 and 6.");
				break;

			case -1:
				break;
			}
		} while (true);
		System.out.println("Exiting simulator.");
		debug.write("simulator exited.");
	}

	private void startMOLoad() {
		keepMOLoadAlive = true;
		System.out.println(" Started MO load test..to stop load select option 10 ...");
		MOLoad moLoad = new MOLoad();
		moLoad.start();
	}

	private void stopMOLoad() {
		keepMOLoadAlive = false;
		System.out.println(" Stopped MO load test.....");
	}

	protected void start() throws IOException {
		if (smscListener == null) {
			System.out.print("Enter port number> ");
			int port = Integer.parseInt(keyboard.readLine());
			System.out.print("Starting listener... DR trackingIdSufix : " + trackingIdSufix);
			smscListener = new SMSCListener(port, true, isSSL);
			smscListener.setUseFileQueueWriterForDR(useWriterForDR);
			smscListener.setUseFileQueueReaderForDR(useReaderForDR);
			processors = new PDUProcessorGroup();
			messageStore = new ShortMessageStore();
			deliveryInfoSender = new DeliveryInfoSender(noDRWorkerThreads);
			if (useWriterForDR) {
				deliveryInfoSender.setFileQueueDir(fileQueueDir);
				deliveryInfoSender.setFileQueueUniqueID(uniqueID);
				deliveryInfoSender.setCommitMsgCount(commitMsgCount);
				deliveryInfoSender.setCommitMsgTimeout(commitMsgTimeout);
				deliveryInfoSender.setDRFileExt(drFileExt);
				deliveryInfoSender.setUseFileQueueWriterForDR(useWriterForDR);
			} 
			if (useReaderForDR) {
				deliveryInfoSender.setFileQueueDir(fileQueueDir);
				deliveryInfoSender.setDRFileExt(drFileExt);
				deliveryInfoSender.setDispatcherThreadCount(dispatcherThreadCount);
				deliveryInfoSender.setFileReaderUniqueId(fileReaderUniqueId);
				deliveryInfoSender.setSleepTimeInterval(sleepTimeInterval);
			}
			users = new Table(usersFileName);
			factory = new SimulatorPDUProcessorFactory(processors, messageStore, deliveryInfoSender, users);
			factory.setDisplayInfo(displayInfo);
			factory.setTrackingIdSufix(trackingIdSufix);
			setMsgDRStatus();
			factory.setSleepTimeToSendDR(sleepTimeToSendDR);            
			smscListener.setPDUProcessorFactory(factory);
			smscListener.start();            
			System.out.println(" Started.");
			if (useUMTP) {
				m_umtp.start();
				display(" Started umtp Server on port : " + umtpPort);
			}    		
		} else {
			System.out.println("Listener is already running.");
		}
	}

	protected void stop() throws IOException {
		if (smscListener != null) {
			System.out.println("Stopping listener...");
			synchronized (processors) {
				int i = processors.count();
				for (int j = 0; j < i; j++) {
					SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(j);
					SMSCSession smscsession = simulatorpduprocessor.getSession();
					System.out.print((new StringBuffer()).append("Stopping session ").append(j).append(": ").append(simulatorpduprocessor.getSystemId()).append(" ...").toString());
					smscsession.stop();
					System.out.println(" stopped.");
				}
			}
			smscListener.stop();
			smscListener = null;
			if(deliveryInfoSender != null) {                
				deliveryInfoSender.stopDRWorkerThreads();
			}
			System.out.println("Stopped.");
		}
	}

	protected void exit() throws IOException {
		stop();
		keepRunning = false;
	}

	protected void messageList() {
		if(smscListener != null)
			messageStore.print();
		else
			System.out.println("You must start listener first.");
	}

	protected void reloadUsers() {
		if (smscListener != null) {
			try {
				if (users != null)
					users.reload();
				else
					users = new Table(usersFileName);
				System.out.println("Users file reloaded.");
			} catch(FileNotFoundException filenotfoundexception) {
				event.write(filenotfoundexception, (new StringBuffer()).append("reading users file ").append(usersFileName).toString());
				filenotfoundexception.printStackTrace(System.err);
			} catch(IOException ioexception) {
				event.write(ioexception, (new StringBuffer()).append("reading users file ").append(usersFileName).toString());
				ioexception.printStackTrace(System.err);
			}
		} else {
			System.out.println("You must start listener first.");
		}
	}

	protected void logToScreen() {
		if (smscListener != null) {
			synchronized (processors) {
				displayInfo = !displayInfo;
				int i = processors.count();
				for (int j = 0; j < i; j++) {
					SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(j);
					simulatorpduprocessor.setDisplayInfo(displayInfo);
				}
			}
			factory.setDisplayInfo(displayInfo);
		}
	}

	protected void listClients() {
		if (smscListener != null) {
			synchronized(processors) {
				int i = processors.count();
				if (i > 0) {
					for (int j = 0; j < i; j++) {
						SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(j);
						System.out.print(simulatorpduprocessor.getSystemId());
						if(!simulatorpduprocessor.isActive())
							System.out.println(" (inactive)");
						else
							System.out.println();
					}
				} else {
					System.out.println("No client connected.");
				}
			}
		} else { 
			System.out.println("You must start listener first.");
		}
	}

	protected void sendMessageFromBytes() throws IOException {
		if(smscListener != null) {
			int i = processors.count();
			if (i > 0) {
				listClients();
				String s;
				if (i > 1) {
					System.out.print("Type name of the destination> ");
					s = keyboard.readLine();
				} else {
					SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
					s = simulatorpduprocessor.getSystemId();
				}


				for (int j = 0; j < i; j++) {
					SimulatorPDUProcessor simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(j);
					if (simulatorpduprocessor1.getSystemId().equals(s)) {
						if(simulatorpduprocessor1.isActive()) {
							System.out.print("Type the message data> ");
							s = keyboard.readLine();
							byte[] msgBytes = hex2data(s);
							ByteBuffer bb = new ByteBuffer(msgBytes);
							try {
								PDU pdu = PDU.createPDU(bb);
								if (pdu instanceof DeliverSM) {
									System.out.println("Sendign a DeliverSM");
									System.out.print("Type sender of Message> ");
									String sender = keyboard.readLine();
									System.out.print("Type Recipient of Message> ");
									String recipient = keyboard.readLine();
									DeliverSM deliver = (DeliverSM) pdu;
									deliver.setSourceAddr(sender);
									deliver.setDestAddr(recipient);
								} else {
									System.out.println("Entered bytes are not Deliver SM ...not setting the sender/reipient...");
								}

								if (pdu instanceof Request) {
									display(" Sending Request sendMessageFromBytes : " + pdu.debugString());
									simulatorpduprocessor1.serverRequest((Request) pdu);
									display("Message sent.");
								} else {
									System.out.println("Entered data is a Response data. Sending responses is not enabled. Dropping the message");
								}
							} catch (Exception e) {
								e.printStackTrace(System.err);
							}

						} else {
							System.out.println("This session is inactive.");
						}
					} else {
						System.out.println("Processor systemid is not matching...");
					}
				}
			} else {
				System.out.println("No client connected.");
			}
		} else {
			System.out.println("You must start listener first.");
		}
	}

	public static byte[] hex2data(String str){
		if (str == null)
			return new byte[0] ;

		int len = str.length();    // probably should check length
		char hex[] = str.toCharArray();
		byte[] buf = new byte[len/2];

		for (int pos = 0; pos < len / 2; pos++)
			buf[pos] = (byte)( ((toDataNibble(hex[2*pos]) << 4) & 0xF0)
					| ( toDataNibble(hex[2*pos + 1])   & 0x0F) );

		return buf;
	}

	public static String data2hex(byte[] data){
		if (data == null){
			return null;
		}
		int len = data.length;
		StringBuffer buf = new StringBuffer(len*2);
		for (int pos = 0; pos < len; pos++){
			buf.append(toHexChar((data[pos]>>>4)&0x0F)).append(toHexChar(data[pos]&0x0F));
		}
		return buf.toString();
	}

	public static char toHexChar(int i){
		if ((0 <= i) && (i <= 9 ))
			return (char)('0' + i);
		else
			return (char)('a' + (i-10));
	}


	public static byte toDataNibble(char c){
		if (('0' <= c) && (c <= '9' ))
			return (byte)((byte)c - (byte)'0');
		else if (('a' <= c) && (c <= 'f' ))
			return (byte)((byte)c - (byte)'a' + 10);
		else if (('A' <= c) && (c <= 'F' ))
			return (byte)((byte)c - (byte)'A' + 10);
		else
			return -1;
	}
	
	private void submitBytes(){
		display(Thread.currentThread().getName()  + " In submitBytes method"); 	
	    
    	try {        	
        	
        	if (smscListener != null) {
    			int i = processors.count();
    			if (i > 0) {
    				listClients();
    				String s;
    				if (i > 1) {
    					System.out.print("Type name of the destination> ");
    					s = keyboard.readLine();
    				} else {
    					SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
    					s = simulatorpduprocessor.getSystemId();
    				}
    				for (int j = 0; j < i; j++) {
    					SimulatorPDUProcessor simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(j);
    					if (simulatorpduprocessor1.getSystemId().equals(s)) {
    						if (simulatorpduprocessor1.isActive()) {
    							System.out.print("Enter bytes :");
    				    	    String str = keyboard.readLine();
    				        	//String str = "000000B7000000040000000001D3DE4B000500576543686174000101383231303335383031323336000000000000010001008457654368617420766572696669636174696F6E20636F646520283836323329206D6179206F6E6C792062652075736564206F6E636520746F20766572696679206D6F62696C65206E756D6265722E20466F72206163636F756E74207361666574792C20646F6E277420666F72776172642074686520636F646520746F206F74686572732E00000083000000040000000001D3DE4F00050057654368617400010139353937373635343939393500000000000001000100505573652074686520636F646520283931353229206F6E2057654368617420746F206C6F6720696E20746F20796F7572206163636F756E742E20446F6E277420666F72776172642074686520636F64652100000083000000040000000001D3DE5300050057654368617400010139353937383439313836313900000000000001000100505573652074686520636F646520283733373129206F6E2057654368617420746F206C6F6720696E20746F20796F7572206163636F756E742E20446F6E277420666F72776172642074686520636F646521000000B7000000040000000001D3DE57000500576543686174000101393539343034393836383933000000000000010001008457654368617420766572696669636174696F6E20636F646520283239333629206D6179206F6E6C792062652075736564206F6E636520746F20766572696679206D6F62696C65206E756D6265722E20466F72206163636F756E74207361666574792C20646F6E277420666F72776172642074686520636F646520746F206F74686572732E00000082000000040000000001D3DE5B000500576543686174000101333436373539343730323100000000000001000100505573652074686520636F646520283836333129206F6E2057654368617420746F206C6F6720696E20746F20796F7572206163636F756E742E20446F6E277420666F72776172642074686520636F64652100000083000000040000000001D3DE5F00050057654368617400010139373135323331323336313500000000000001000100505573652074686520636F646520283637363729206F6E2057654368617420746F206C6F6720696E20746F20796F7572206163636F756E742E20446F6E277420666F72776172642074686520636F646521000000B7000000040000000001D3DE63000500576543686174000101383231303636323633303337000000000000010001008457654368617420766572696669636174696F6E20636F646520283431343229206D6179206F6E6C792062652075736564206F6E636520746F20766572696679206D6F62696C65206E756D6265722E20466F72206163636F756E74207361666574792C20646F6E277420666F72776172642074686520636F646520746F206F74686572732E000000B7000000040000000001D3DE67000500576543686174000101393539343031333538353437000000000000010001008457654368617420766572696669636174696F6E20636F646520283535323629206D6179206F6E6C792062652075736564206F6E636520746F20766572696679206D6F62696C65206E756D6265722E20466F72206163636F756E74207361666574792C20646F6E277420666F72776172642074686520636F646520746F206F74686572732E00000083000000040000000001D3DE6B00050057654368617400010132313839343430303830343100000000000001000100505573652074686520636F646520283838353129206F6E2057654368617420746F206C6F6720696E20746F20796F7572206163636F756E742E20446F6E277420666F72776172642074686520636F64652100000084000000040000000001D3DE6F0005005765436861740001013838303139313631363436393100000000000001000100505573652074686520636F646520283335363629206F6E";
    				        	byte[] msgBytes = hex2data(str);
    							ByteBuffer bb = new ByteBuffer(msgBytes);    							
    							PDU pdu = PDU.createPDU(bb);
    							simulatorpduprocessor1.getSession().send(pdu);
    						}
    					}
    				}
    			}
        	} 	
		
		} catch (UnknownHostException e) {
			display(Thread.currentThread().getName()  + " In submitBytes method : "+e); 	
		} catch (IOException e) {
			display(Thread.currentThread().getName()  + " In submitBytes method : "+e);
		}catch (Exception e) {
			display(Thread.currentThread().getName()  + " In submitBytes method : "+e);
		}
	}

	protected void sendMessage() throws IOException {
		if (smscListener != null) {
			int i = processors.count();
			if (i > 0) {
				listClients();
				String s;
				if (i > 1) {
					System.out.print("Type name of the destination> ");
					s = keyboard.readLine();
				} else {
					SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
					s = simulatorpduprocessor.getSystemId();
				}
				for (int j = 0; j < i; j++) {
					SimulatorPDUProcessor simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(j);
					if (simulatorpduprocessor1.getSystemId().equals(s)) {
						if (simulatorpduprocessor1.isActive()) {
							System.out.print("Send MO/DR(type M for MO and D for DR):");
							String s3 = keyboard.readLine();
							String s4 = "887781";
							String s5 = "19845992554";
							String s6 = "testing drs";
							System.out.print("Type the destination addrs> ");
							s4 = keyboard.readLine();
							System.out.print("Type the source addrs> ");
							s5 = keyboard.readLine();
							System.out.print("Send Long Message: Y/N : ");
							String msgType = keyboard.readLine();
							String udhLength = "0";
							String referenceId = "20";
							String isSAR = "N";


							String  sarMsgRefNumId = "524";
							String  sarMsgRefNumValue ="1000";

							String	sarTotalSegmentsId ="526";
							String	sarTotalSegmentsValue ="1";

							String	sarSegmentSeqnumId ="527";
							String	sarSegmentSeqnumValue="1";
							int intSarMsgRefNumValue = 1;
							if(msgType.equalsIgnoreCase("Y")){
								System.out.print(" Enter long Message : ");
								s6 = keyboard.readLine();

								System.out.print("is it SAR: Y/N : ");
								isSAR =keyboard.readLine();

								if(isSAR.equalsIgnoreCase("Y")) {

									System.out.print("Type the sar sarMsgRefNumId  for MO> 524: ");
									sarMsgRefNumId = keyboard.readLine();


									System.out.print("Type the sar sarMsgRef Value : ");
									//sarMsgRefNumValue = String.valueOf(getRandomNumberInRange(10, 99));
									//intSarMsgRefNumValue = getRandomNumberInRange(10, 99);
									 sarMsgRefNumValue = keyboard.readLine();
									 try {
										intSarMsgRefNumValue = Integer.parseInt(sarMsgRefNumValue);
									} catch (NumberFormatException e) {
										System.out.println("NumberFormatException- Defaulting RefId to 20 ");
										intSarMsgRefNumValue = 20;
									}
									
									System.out.print("Type the sar sarTotalSegmentsId  for MO> 526: ");
									sarTotalSegmentsId = keyboard.readLine();	



									System.out.print("Type the sar sarSegmentSeqnumId  for MO> 527: ");
									sarSegmentSeqnumId = keyboard.readLine();


									udhLength = "0";


								}else {
									System.out.print("6/7 byte UDH? : ");
									udhLength = keyboard.readLine();
									if(udhLength.equals("7"))
										System.out.print("Type reference ID withing the Range  [0-65000]: ");
									else
										System.out.print("Type reference ID withing the Range  [0-254]: ");
									referenceId = keyboard.readLine();
								}


							}else{
								System.out.print("Type the message> ");
								s6 = keyboard.readLine();
							}
							System.out.print("Type the dcs for MO>  0:Text:,8:UCS2,3:Latin1,1:GSM - ");
							String dcs = keyboard.readLine();

							System.out.print("Type the senderOpid TLV Tag for MO> ");
							String senderOpidTLVTag = keyboard.readLine();

							System.out.print("Type the senderOpid TLV Value for MO> ");
							String senderOpidTLVVal = keyboard.readLine();





							try {
								DeliverSM deliversm = new DeliverSM();
								String s7 = "";
								deliversm.setDataCoding(Byte.parseByte(dcs));
								deliversm.setDestAddr(s4);
								deliversm.setSourceAddr(s5);
								ByteBuffer bytebuffer = new ByteBuffer();
								bytebuffer.appendString("test");
								deliversm.setExtraOptional((short)98, bytebuffer);

								if (senderOpidTLVTag != null && !senderOpidTLVTag.trim().equals("")) {
									ByteBuffer senderOpidTLVValBB = new ByteBuffer();
									senderOpidTLVValBB.appendString(senderOpidTLVVal);
									deliversm.setExtraOptional(Short.parseShort(senderOpidTLVTag), senderOpidTLVValBB);
								}



								if(s3.equalsIgnoreCase("D")) {
									System.out.print("Type the msgid> ");
									String s2 = keyboard.readLine();
									s7 = (new StringBuffer()).append(s7).append("id:").append(s2).append(" ").toString();
									s7 = (new StringBuffer()).append(s7).append("sub:1 ").toString();
									s7 = (new StringBuffer()).append(s7).append("dlvrd:1 ").toString();
									s7 = (new StringBuffer()).append(s7).append("submit date:0511281842  ").toString();
									s7 = (new StringBuffer()).append(s7).append("done date:0511281842  ").toString();
									s7 = (new StringBuffer()).append(s7).append("stat:").append(deliveryInfoSender.getDRStatus()).append(" ").toString();
									s7 = (new StringBuffer()).append(s7).append("err:").append(deliveryInfoSender.getDRStatusCode()).append(" ").toString();
									s7 = (new StringBuffer()).append(s7).append("text:").append(s6).toString();
								}
								if(s3.equalsIgnoreCase("M")) {
									s7 = s6;
									display((new StringBuffer()).append("***message :").append(s7).toString());
								} else {
									deliversm.setEsmClass(Byte.parseByte(deliveryInfoSender.getEsmClass()));
								}
								String [] msgs = new String[1];


								if(isSAR.equalsIgnoreCase("N"))                                
									msgs = getSplitMessages(s7, dcs, udhLength);
								else
									msgs = getSplitMessagesText(s7, dcs);



								int intdcs = 0;
								try {
									intdcs = Integer.parseInt(dcs);
								} catch(Exception e){}

								if (msgs.length > 1) {
									int udhInt=0;
									try {
										udhInt = Integer.parseInt(udhLength);
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
								}

								int rand = (udhInt == 7)?getRandomNumberInRange(0,65000):getRandomNumberInRange(0,255);

									for (int l = 0; l < msgs.length; l++) {

										String tmp = msgs[l];
										byte[] tmpBytes = null;
										if(intdcs == 8){
											tmpBytes = tmp.getBytes("UTF-16BE");
										}else 
											tmpBytes = tmp.getBytes("iso-8859-1");


										byte[] finalBytes;
										int refid = 20;
										try {
											refid = Integer.parseInt(referenceId);
										} catch (Exception e) {
											System.out.println("Exception parsing reference ID - " + referenceId);
										}
display("Reference Id --- : " + refid);

										if(udhInt == 7){
											byte[] refId = intToByteArray(refid);
											finalBytes = new byte[tmpBytes.length + 7];

											finalBytes[0] = (byte) 6;
											finalBytes[1] = (byte) 8;
											finalBytes[2] = (byte) 4;	                                		

											finalBytes[3] = refId[0];
											finalBytes[4] = refId[1];


											finalBytes[5] = (byte) msgs.length;
											finalBytes[6] = (byte) (l + 1);
										
display("UDH Bytes : " + data2hex(finalBytes));
	System.arraycopy(tmpBytes, 0, finalBytes, 7, tmpBytes.length);
display("Final UDH Bytes : " + data2hex(finalBytes));
										}else if (udhInt == 6){

											finalBytes = new byte[tmpBytes.length + 6];
											finalBytes[0] = (byte) 5;
											finalBytes[1] = (byte) 0;
											finalBytes[2] = (byte) 3;
											finalBytes[3] = (byte) refid;
											finalBytes[4] = (byte) msgs.length;
											finalBytes[5] = (byte) (l + 1);
display("UDH Bytes : " + data2hex(finalBytes));
											System.arraycopy(tmpBytes, 0, finalBytes, 6, tmpBytes.length);
display("Final UDH Bytes : " + data2hex(finalBytes));					
					}else {
											finalBytes = new byte[tmpBytes.length];
											System.arraycopy(tmpBytes, 0, finalBytes, 0, tmpBytes.length);
										}
										deliversm.setShortMessage(new String(finalBytes,"ISO-8859-1"), "ISO-8859-1");
										deliversm.setEsmClass((byte)64);                                       


										if(isSAR.equalsIgnoreCase("Y")) {
											deliversm.setEsmClass((byte)0);
											if (sarMsgRefNumId != null && !sarMsgRefNumId.trim().equals("")) {
												ByteBuffer sarMsgRefNumValueBB = new ByteBuffer();
												//sarMsgRefNumValueBB.appendString(data2hex(sarMsgRefNumValue.getBytes("UTF-8")));
                                                byte[] refId2 = intToByteArray(intSarMsgRefNumValue);
                                                sarMsgRefNumValueBB.appendBytes(refId2);
												deliversm.setExtraOptional(Short.parseShort(sarMsgRefNumId), sarMsgRefNumValueBB);
											}

											sarTotalSegmentsValue = String.valueOf(msgs.length);
											sarSegmentSeqnumValue = String.valueOf((l + 1));

											System.out.println(" intSarMsgRefNumValue " + intSarMsgRefNumValue);
											System.out.println(" sarTotalSegmentsValue " + sarTotalSegmentsValue);
											System.out.println(" sarSegmentSeqnumValue " + sarSegmentSeqnumValue);

											if (sarTotalSegmentsId != null && !sarTotalSegmentsId.trim().equals("")) {
												ByteBuffer sarTotalSegmentsValueBB = new ByteBuffer();
												sarTotalSegmentsValueBB.appendByte(Byte.parseByte(sarTotalSegmentsValue));
												deliversm.setExtraOptional(Short.parseShort(sarTotalSegmentsId), sarTotalSegmentsValueBB);      									

											}

											if (sarSegmentSeqnumId != null && !sarSegmentSeqnumId.trim().equals("")) {
												ByteBuffer sarSegmentSeqnumValueBB = new ByteBuffer();
												sarSegmentSeqnumValueBB.appendByte(Byte.parseByte(sarSegmentSeqnumValue));
												deliversm.setExtraOptional(Short.parseShort(sarSegmentSeqnumId), sarSegmentSeqnumValueBB);
											}
										}
										display(" Sending Request sendMessage : " + deliversm.debugString());
										simulatorpduprocessor1.serverRequest(deliversm);
										System.out.println("Message sent.");
									}
								} else {
									deliversm.setShortMessage(s7);
									simulatorpduprocessor1.serverRequest(deliversm);
									display(" Sending Request sendMessage : " + deliversm.debugString());
									System.out.println("Message sent.");
								}
								Thread.sleep(1000L);
							} catch(WrongLengthOfStringException wronglengthofstringexception) {
								wronglengthofstringexception.printStackTrace(System.err);
								System.out.println("Message sending failed");
								event.write(wronglengthofstringexception, "");
							} catch (Exception exception) {
								exception.printStackTrace(System.err);
								System.out.println("Message sending failed");
								event.write(exception, "");
							}
						} else {
							System.out.println("This session is inactive.");
						}
					}
				}
			} else {
				System.out.println("No client connected.");
			}
		} else {
			System.out.println("You must start listener first.");
		}
	}

	protected void sendMessageToMultiBind() throws IOException {
		System.out.println("Using sendMessageToMultiBind() call.");
		if (smscListener != null) {
			int i = processors.count();
			if (i > 0) {
				listClients();
				String s;
				if (i > 1) {
					System.out.print("Type name of the destination> ");
					s = keyboard.readLine();
				} else {
					SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
					s = simulatorpduprocessor.getSystemId();
				}
				for (int j = 0; j < i; j++) {
					SimulatorPDUProcessor simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(j);
					if (simulatorpduprocessor1.getSystemId().equals(s)) {
						if (simulatorpduprocessor1.isActive()) {
							System.out.print("Send MO/DR(type M for MO and D for DR):");
							String s3 = keyboard.readLine();
							String s4 = "887781";
							String s5 = "19845992554";
							String s6 = "testing drs";
							System.out.print("Type the destination addrs> ");
							s4 = keyboard.readLine();
							System.out.print("Type the source addrs> ");
							s5 = keyboard.readLine();
							System.out.print("Send Long Message: Y/N : ");
							String msgType = keyboard.readLine();
							String udhLength = "0";
							String isSAR = "N";


							String  sarMsgRefNumId = "524";
							String  sarMsgRefNumValue ="1000";

							String	sarTotalSegmentsId ="526";
							String	sarTotalSegmentsValue ="1";

							String	sarSegmentSeqnumId ="527";
							String	sarSegmentSeqnumValue="1";
							int intSarMsgRefNumValue = 1;
							
							if(msgType.equalsIgnoreCase("Y")){
								System.out.print(" Enter long Message : ");
								s6 = keyboard.readLine();

								System.out.print("is it SAR: Y/N : ");
								isSAR =keyboard.readLine();

								if(isSAR.equalsIgnoreCase("Y")) {

									System.out.print("Type the sar sarMsgRefNumId  for MO> 524: ");
									sarMsgRefNumId = keyboard.readLine();


									//sarMsgRefNumValue = String.valueOf(getRandomNumberInRange(10, 99));
									intSarMsgRefNumValue = getRandomNumberInRange(10, 99);
									System.out.print("Type the sar sarTotalSegmentsId  for MO> 526: ");
									sarTotalSegmentsId = keyboard.readLine();	



									System.out.print("Type the sar sarSegmentSeqnumId  for MO> 527: ");
									sarSegmentSeqnumId = keyboard.readLine();


									udhLength = "0";


								}else {
									System.out.print("6/7 byte UDH? : ");
									udhLength = keyboard.readLine();
								}


							}else{
								System.out.print("Type the message> ");
								s6 = keyboard.readLine();
							}
							System.out.print("Type the dcs for MO>  0:Text:,8:UCS2,3:Latin1,1:GSM - ");
							String dcs = keyboard.readLine();

							System.out.print("Type the senderOpid TLV Tag for MO> ");
							String senderOpidTLVTag = keyboard.readLine();

							System.out.print("Type the senderOpid TLV Value for MO> ");
							String senderOpidTLVVal = keyboard.readLine();


							try {
								DeliverSM deliversm = new DeliverSM();
								String s7 = "";
								deliversm.setDataCoding(Byte.parseByte(dcs));
								deliversm.setDestAddr(s4);
								deliversm.setSourceAddr(s5);
								ByteBuffer bytebuffer = new ByteBuffer();
								bytebuffer.appendString("test");
								deliversm.setExtraOptional((short)98, bytebuffer);

								if (senderOpidTLVTag != null && !senderOpidTLVTag.trim().equals("")) {
									ByteBuffer senderOpidTLVValBB = new ByteBuffer();
									senderOpidTLVValBB.appendString(senderOpidTLVVal);
									deliversm.setExtraOptional(Short.parseShort(senderOpidTLVTag), senderOpidTLVValBB);
								}



								if(s3.equalsIgnoreCase("D")) {
									System.out.print("Type the msgid> ");
									String s2 = keyboard.readLine();
									s7 = (new StringBuffer()).append(s7).append("id:").append(s2).append(" ").toString();
									s7 = (new StringBuffer()).append(s7).append("sub:1 ").toString();
									s7 = (new StringBuffer()).append(s7).append("dlvrd:1 ").toString();
									s7 = (new StringBuffer()).append(s7).append("submit date:0511281842  ").toString();
									s7 = (new StringBuffer()).append(s7).append("done date:0511281842  ").toString();
									s7 = (new StringBuffer()).append(s7).append("stat:").append(deliveryInfoSender.getDRStatus()).append(" ").toString();
									s7 = (new StringBuffer()).append(s7).append("err:").append(deliveryInfoSender.getDRStatusCode()).append(" ").toString();
									s7 = (new StringBuffer()).append(s7).append("text:").append(s6).toString();
								}
								if(s3.equalsIgnoreCase("M")) {
									s7 = s6;
									display((new StringBuffer()).append("***message :").append(s7).toString());
								} else {
									deliversm.setEsmClass(Byte.parseByte(deliveryInfoSender.getEsmClass()));
								}
								String [] msgs = new String[1];


								if(isSAR.equalsIgnoreCase("N"))                                
									msgs = getSplitMessages(s7, dcs, udhLength);
								else
									msgs = getSplitMessagesText(s7, dcs);



								int intdcs = 0;
								try {
									intdcs = Integer.parseInt(dcs);
								} catch(Exception e){}

								if (msgs.length > 1) {
									int b=0;
									int rand = 0;
									int udhInt=0;
									try {
										udhInt = Integer.parseInt(udhLength);
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									
									rand = (udhInt == 7)?getRandomNumberInRange(0,65000):getRandomNumberInRange(0,255);
									for (int l = 0; l < msgs.length; l++) {
										System.out.print("Message Submit: b = " + b + ", processsor i = " + i);		
										if(b >= i) b=0;

										simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(b++);
										System.out.print("Message Submit: b = " + b + ", processsor i = " + i);		

										String tmp = msgs[l];
										byte[] tmpBytes = null;
										if(intdcs == 8){
											tmpBytes = tmp.getBytes("UTF-16BE");
										}else 
											tmpBytes = tmp.getBytes("iso-8859-1");


										byte[] finalBytes;
										if(udhInt == 7){

											//int rand = getRandomNumberInRange(0,65000);
											byte[] refId = intToByteArray(rand);

											finalBytes = new byte[tmpBytes.length + 7];



											finalBytes[0] = (byte) 6;
											finalBytes[1] = (byte) 8;
											finalBytes[2] = (byte) 4;	                                		

											finalBytes[3] = refId[0];
											finalBytes[4] = refId[1];


											finalBytes[5] = (byte) msgs.length;
											finalBytes[6] = (byte) (l + 1);
											System.arraycopy(tmpBytes, 0, finalBytes, 7, tmpBytes.length);
										}else if (udhInt == 6){

											finalBytes = new byte[tmpBytes.length + 6];
											finalBytes[0] = (byte) 5;
											finalBytes[1] = (byte) 0;
											finalBytes[2] = (byte) 3;
											finalBytes[3] = (byte) rand;
											finalBytes[4] = (byte) msgs.length;
											finalBytes[5] = (byte) (l + 1);
											System.arraycopy(tmpBytes, 0, finalBytes, 6, tmpBytes.length);
										}else {
											finalBytes = new byte[tmpBytes.length];
											System.arraycopy(tmpBytes, 0, finalBytes, 0, tmpBytes.length);
										}
										deliversm.setShortMessage(new String(finalBytes));
										deliversm.setEsmClass((byte)64);                                       


										if(isSAR.equalsIgnoreCase("Y")) {
											deliversm.setEsmClass((byte)0);
											if (sarMsgRefNumId != null && !sarMsgRefNumId.trim().equals("")) {
												ByteBuffer sarMsgRefNumValueBB = new ByteBuffer();
												//sarMsgRefNumValueBB.appendString(data2hex(sarMsgRefNumValue.getBytes("UTF-8")));
                                                byte[] refId2 = intToByteArray(intSarMsgRefNumValue);
                                                sarMsgRefNumValueBB.appendBytes(refId2);
												deliversm.setExtraOptional(Short.parseShort(sarMsgRefNumId), sarMsgRefNumValueBB);
											}

											sarTotalSegmentsValue = String.valueOf(msgs.length);
											sarSegmentSeqnumValue = String.valueOf((l + 1));

											System.out.println(" intSarMsgRefNumValue " + intSarMsgRefNumValue);
											System.out.println(" sarTotalSegmentsValue " + sarTotalSegmentsValue);
											System.out.println(" sarSegmentSeqnumValue " + sarSegmentSeqnumValue);

											if (sarTotalSegmentsId != null && !sarTotalSegmentsId.trim().equals("")) {
												ByteBuffer sarTotalSegmentsValueBB = new ByteBuffer();
												sarTotalSegmentsValueBB.appendByte(Byte.parseByte(sarTotalSegmentsValue));
												deliversm.setExtraOptional(Short.parseShort(sarTotalSegmentsId), sarTotalSegmentsValueBB);      									

											}

											if (sarSegmentSeqnumId != null && !sarSegmentSeqnumId.trim().equals("")) {
												ByteBuffer sarSegmentSeqnumValueBB = new ByteBuffer();
												sarSegmentSeqnumValueBB.appendByte(Byte.parseByte(sarSegmentSeqnumValue));
												deliversm.setExtraOptional(Short.parseShort(sarSegmentSeqnumId), sarSegmentSeqnumValueBB);
											}
										}
										display(" Sending Request sendMessage : " + deliversm.debugString());
										simulatorpduprocessor1.serverRequest(deliversm);
										System.out.println("Message sent.");
									}
								} else {
									deliversm.setShortMessage(s7);
									simulatorpduprocessor1.serverRequest(deliversm);
									display(" Sending Request sendMessage : " + deliversm.debugString());
									System.out.println("Message sent.");
								}
								Thread.sleep(1000L);
							} catch(WrongLengthOfStringException wronglengthofstringexception) {
								wronglengthofstringexception.printStackTrace(System.err);
								System.out.println("Message sending failed");
								event.write(wronglengthofstringexception, "");
							} catch (Exception exception) {
								exception.printStackTrace(System.err);
								System.out.println("Message sending failed");
								event.write(exception, "");
							}
						} else {
							System.out.println("This session is inactive.");
						}
					}
				}
			} else {
				System.out.println("No client connected.");
			}
		} else {
			System.out.println("You must start listener first.");
		}
	}

	
	private byte[] intToByteArray(int value) {
		byte[] b = new byte[2];
		int MASK = 0xff;

		for (int i = 0; i < 2; i++) {
			int offset = (b.length - 1 - i) * 8;
			b[i] = (byte) ((value >> offset) & MASK);
		}
		return b;
	}


	private String[] getSplitMessages(String message, String dcs, String udhLength){
		int intdcs = 0;
		int numberOfSplits = 1;
		int udhSize =6;
		int splitLength =0 ;
		String[] msgs = new String[1];
		try {
			udhSize  = Integer.parseInt(udhLength);
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			intdcs = Integer.parseInt(dcs);
		} catch (NumberFormatException e) {}

		if(intdcs == 0 || intdcs == 1){
			if (udhSize == 7){
				splitLength = 153;
				numberOfSplits = getNumOfSplits(message , splitLength);

			}else{
				splitLength = 154;
				numberOfSplits = getNumOfSplits(message , splitLength);
			}
		}
		else if (intdcs == 8){
			if (udhSize == 7){
				splitLength = 63;
				numberOfSplits = getNumOfSplits(message , splitLength);
			}else{
				splitLength = 64;
				numberOfSplits = getNumOfSplits(message , splitLength);
			}

		}else if (intdcs == 3){
			if (udhSize == 7){
				splitLength = 133;
				numberOfSplits = getNumOfSplits(message , splitLength);
			}else{
				splitLength = 134;
				numberOfSplits = getNumOfSplits(message , splitLength);
			}
		}

		int currentPos = 0;

		msgs = new String[numberOfSplits];

		for  (int k = 0; k < numberOfSplits; k++) {
			String msg = "";
			if (k == numberOfSplits -1) {
				msg = message.substring(currentPos);
			} else {
				msg = message.substring(currentPos, currentPos + splitLength);
			}
			System.out.println("Concatenated  message part : " + k + " is : " + msg);
			msgs[k] = msg;
			currentPos += splitLength;
		}

		return msgs;
	}


	private String[] getSplitMessagesText(String message, String dcs){
		int intdcs = 0;
		int numberOfSplits = 1;

		int splitLength =0 ;
		String[] msgs = new String[1];

		try {
			intdcs = Integer.parseInt(dcs);
		} catch (NumberFormatException e) {}

		if(intdcs == 0 || intdcs == 1){    		
			splitLength = 160;
			numberOfSplits = getNumOfSplits(message , splitLength);
		}
		else if (intdcs == 8){

			splitLength = 70;
			numberOfSplits = getNumOfSplits(message , splitLength);


		}else if (intdcs == 3){    		
			splitLength = 140;
			numberOfSplits = getNumOfSplits(message , splitLength);   		
		}

		int currentPos = 0;

		msgs = new String[numberOfSplits];

		for  (int k = 0; k < numberOfSplits; k++) {
			String msg = "";
			if (k == numberOfSplits -1) {
				msg = message.substring(currentPos);
			} else {
				msg = message.substring(currentPos, currentPos + splitLength);
			}
			System.out.println("Concatenated  message part : " + k + " is : " + msg);
			msgs[k] = msg;
			currentPos += splitLength;
		}

		return msgs;
	}

	private int getNumOfSplits(String message , int length){
		System.out.println("Making the message concatenations...");
		int numOfMsgs = 1;
		if (message.length() % length == 0)
			numOfMsgs = message.length() / length;
		else
			numOfMsgs = (message.length() / length) + 1;

		return numOfMsgs;
	}


	private void submitBinaryMessage() {

		System.out.println(Thread.currentThread().getName()  + " In submitBinaryMessage method");        
		if (smscListener != null) {
			int i = processors.count();
			if (i > 0) {
				listClients();
				SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
				String s = simulatorpduprocessor.getSystemId();
				for (int j = 0; j < i; j++) {
					SimulatorPDUProcessor simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(j);
					if (simulatorpduprocessor1.getSystemId().equals(s)) {
						if (simulatorpduprocessor1.isActive()) {
							try {
								int dataCoding = 0;
								DeliverSM request = new DeliverSM();
								System.out.println("Enter Source Address");
								String sourceAddress = keyboard.readLine();

								System.out.println("Enter Destination Address");
								String destAddress = keyboard.readLine();

								System.out.println("The Binary short message");
								String shortMessage = keyboard.readLine();

								System.out.println("Data encoding");
								String dataCodingStr = keyboard.readLine();

								if (dataCodingStr != null) {
									dataCoding = Integer.parseInt(dataCodingStr);
								}
								request.setSourceAddr(sourceAddress);
								request.setDestAddr(destAddress);
								byte[] binaryMsgBytes = hex2data(shortMessage);
								ShortMessage binarySM = new ShortMessage(binaryMsgBytes.length);
								binarySM.setData(new ByteBuffer(binaryMsgBytes));            
								request.setShortMessage(binarySM);			            
								request.setDataCoding((byte) dataCoding);

								display(Thread.currentThread().getName()  + " Request  = " + request.debugString());
								int count = 1;
								System.err.println();					            
								System.out.println("How many times to submit this message (load test)");

								String countStr = keyboard.readLine();
								if (countStr != null) {
									count = Integer.parseInt(countStr);					            	
								}

								for (int k = 0; k < count; k++) {
									request.assignSequenceNumber(true);
									System.err.println("# " + k + " Submit request " + request.debugString());
									simulatorpduprocessor1.serverRequest(request);
									System.err.println();
								}
							} catch (Exception e) {
								event.write(e, "");
								debug.write("Submit operation failed. " + e);
								System.err.println("Submit operation failed. " + e);
							} finally {
								debug.exit(this);
							}
						} else {
							System.out.println("This session is inactive.");
						}
					}
				}
			} else {
				System.out.println("No client connected.");
			}
		} else {
			System.out.println("You must start listener first.");
		}
	}

	public void display(String s) {
		long timestamp1 = System.currentTimeMillis();
		System.err.println((new Timestamp(timestamp1)).toString() + " [pavel] " + s);
	}

	private void setMsgDRStatus() {
		display(" setMsgDRStatus() started!....count : " + processors.count());
		display(" MsgCommandStatus : " + msgCommandStatus + " DRStatus : " + DRStatus + " DRStatusCode : " + DRStatusCode);
		if (deliveryInfoSender != null) {
			deliveryInfoSender.setDRStatus(DRStatus);
			deliveryInfoSender.setDRStatusCode(DRStatusCode);
			deliveryInfoSender.setMessageState(messageState);
			deliveryInfoSender.setNetworkErrCode(networkErrCode);
			deliveryInfoSender.setEsmClass(esm_class);
			deliveryInfoSender.setReceiptedMessageId(deliveryInfoSender.getMsgId());
			if(isEnabled) {
				deliveryInfoSender.setUserMessageReference(userMsgRef);
			}
		}
		smscListener.setCommandStatus(Integer.parseInt(msgCommandStatus));
		if (processors.count() > 0) {
			SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
			if (simulatorpduprocessor != null) {
				simulatorpduprocessor.setCommandStatus(Integer.parseInt(msgCommandStatus));
				simulatorpduprocessor.setSleepTimeToSendDR(sleepTimeToSendDR);
			}
		}
		display(" setMsgDRStatus() ended!....");
	}

	static final String copyright = "Copyright (c) 1996-2001 Logica Mobile Networks Limited\nThis product includes software developed by Logica by whom copyright\nand know-how are retained, all rights reserved.\n";
	static String usersFileName = "users.txt";
	static final String dbgDir = "./";
	static Debug debug = new FileDebug("./", "sim.dbg");
	static Event event = new FileEvent("./", "sim.evt");
	public static final int DSIM = 16;
	public static final int DSIMD = 17;
	public static final int DSIMD2 = 18;
	static BufferedReader keyboard;
	private boolean keepRunning;
	private SMSCListener smscListener;
	private SimulatorPDUProcessorFactory factory;
	private PDUProcessorGroup processors;
	private ShortMessageStore messageStore;
	private DeliveryInfoSender deliveryInfoSender;
	private Table users;
	private boolean displayInfo;
	private Vector loadTestSenderCSVList = new Vector();
	private Vector loadTestDestinationCSVList = new Vector();
	private String loadTestSM;
	private byte loadTestRegisteredDelivery;
	private byte loadTestEsmClass;
	private int loadTestDataCoding;
	private int loadTestSleepInterval;
	private Random shortMsgRandNumGenerator = new Random();
	private Random sourceAddrRandNumGenerator = new Random();
	private Random destAddrRandNumGenerator = new Random();
	private String logfile;
	private String trackingIdSufix;
	private long sleepTimeToSendDR;
	private int noDRWorkerThreads;
	private boolean isSSL;
	private boolean useUMTP = false;
	private UMTP m_umtp = null;
	private int umtpPort;
	private Properties properties = null;
	private String DRStatus = "delivrd";
	private String DRStatusCode = "000";
	private String messageState;
	private String userMsgRef;
	private String networkErrCode;
	private String esm_class = "4";
	private String msgCommandStatus = "0";
	private boolean keepMOLoadAlive = false;	
	private String fileQueueDir = null;
	private String uniqueID = null;
	private int commitMsgCount;
	private int commitMsgTimeout;
	private String drFileExt = null;
	private int dispatcherThreadCount;
	private String fileReaderUniqueId = null;
	private int sleepTimeInterval;
	private boolean useWriterForDR = false;
	private boolean useReaderForDR = false;
	private boolean isEnabled = false;

	static {
		System.out.println("Copyright (c) 1996-2001 Logica Mobile Networks Limited\nThis product includes software developed by Logica by whom copyright\nand know-how are retained, all rights reserved.\n");
		keyboard = new BufferedReader(new InputStreamReader(System.in));
	}

	private class UMTP extends UMTPServer {

		public UMTP (int port, int cmdHandlers) {
			super(port, cmdHandlers);
			setListner(new Listner());
		}

		class Listner implements Session.Listner {

			public Response onCommand(Session s, Session.CommandHandler h, Command cmd) {
				try {
					if (cmd instanceof CmdBind) {
						return new Response(Response.Code.SUCCESS);
					} else if (cmd instanceof Refresh){
						return refreshProps((Refresh)cmd);
					} else {
						return new Response(Response.Code.E_INVALID_CMD, cmd.toString());
					}
				} catch (Exception ex) {
					return new Response(Response.Code.SUCCESS,"FAILED TO HANDLE ON THE RECEIVED COMMAND");
				}
			}
			public void onExit(Session s) {
			}
		}
	}

	private Response refreshProps(Refresh cmd) {
		display(" Processing Refresh command ");
		refreshProperties();
		setMsgDRStatus();
		return  new Response(Response.Code.SUCCESS, " Reloaded properties and Msg, DR status set Successfully!! ");
	}

	private int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		return r.nextInt((max - min) + 1) + min;
	}

	private class MOLoad extends Thread {
		public void run() {
			try {
				if(smscListener != null) {
					int i = processors.count();
					if (i > 0) {
						listClients();
						String s;
						if (i > 1) {
							System.out.print("Type name of the destination> ");
							s = keyboard.readLine();
						} else {
							SimulatorPDUProcessor simulatorpduprocessor = (SimulatorPDUProcessor)processors.get(0);
							s = simulatorpduprocessor.getSystemId();
						}

						for (int j = 0; j < i; j++) {
							SimulatorPDUProcessor simulatorpduprocessor1 = (SimulatorPDUProcessor)processors.get(j);
							if (simulatorpduprocessor1.getSystemId().equals(s)) {
								if (simulatorpduprocessor1.isActive()) {
									while (keepMOLoadAlive) {
										try {
											Thread.sleep(loadTestSleepInterval);
										} catch(Exception e) {
											e.printStackTrace(System.err);
											display("Sleep got interrupted..continuing load test..");
										}
										DeliverSM request = new DeliverSM();
										request.setSourceAddr((String)loadTestSenderCSVList.get(sourceAddrRandNumGenerator.nextInt(loadTestSenderCSVList.size())));
										request.setDestAddr((String)loadTestDestinationCSVList.get(destAddrRandNumGenerator.nextInt(loadTestDestinationCSVList.size())));
										request.setShortMessage(loadTestSM + shortMsgRandNumGenerator.nextInt());
										request.setEsmClass(loadTestEsmClass);
										request.setRegisteredDelivery(loadTestRegisteredDelivery);
										request.setDataCoding((byte) loadTestDataCoding);
										request.assignSequenceNumber(true);		                			
										display(" Sending Request MOLOAD : " + request.debugString());
										simulatorpduprocessor1.serverRequest((Request) request);
									}
								} else {
									System.out.println("This session is inactive.");
								}
							} else {
								System.out.println("Processor systemid is not matching...");
							}
						}
					} else {
						System.out.println("No client connected.");
					}
				} else {
					System.out.println("You must start listener first.");
				}
			} catch (Exception e) {
				e.printStackTrace(System.err);
			}
		}
	}
}
