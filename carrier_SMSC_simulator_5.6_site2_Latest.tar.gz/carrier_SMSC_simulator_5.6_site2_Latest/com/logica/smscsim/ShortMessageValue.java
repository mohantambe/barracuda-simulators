package com.logica.smscsim;

import com.logica.smpp.pdu.SubmitSM;

class ShortMessageValue {

    ShortMessageValue(String systemId, SubmitSM submit) {
        this.systemId = systemId;
        serviceType = submit.getServiceType();
        sourceAddr = submit.getSourceAddr().getAddress();
        destinationAddr = submit.getDestAddr().getAddress();
        shortMessage = submit.getShortMessage();
    }
    String systemId;
    String serviceType;
    String sourceAddr;
    String destinationAddr;
    String shortMessage;
}