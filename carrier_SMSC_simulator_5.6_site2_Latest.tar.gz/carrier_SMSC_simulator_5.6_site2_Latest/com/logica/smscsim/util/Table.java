// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Table.java

package com.logica.smscsim.util;

import java.io.*;
import java.util.*;

// Referenced classes of package com.logica.smscsim.util:
//            Record, BasicTableParser, Attribute, TableParser

public class Table
{

    public Table()
    {
        fileName = null;
        records = new LinkedList();
    }

    public Table(String fileName)
        throws FileNotFoundException, IOException
    {
        this.fileName = fileName;
        read(fileName);
    }

    public synchronized void add(Record record)
    {
        records.add(record);
    }

    public synchronized void add(Record record, Attribute key)
    {
        replace(record, key);
    }

    public synchronized void replace(Record record, Attribute oldKey)
    {
        Record old = find(oldKey);
        if(old != null)
            remove(oldKey);
        add(record);
    }

    public synchronized Record find(Attribute key)
    {
        if(key != null)
            return find(key.getName(), key.getValue());
        else
            return null;
    }

    public synchronized Record find(String name, String value)
    {
        for(ListIterator iter = records.listIterator(0); iter.hasNext();)
        {
            Record current = (Record)iter.next();
            String currKeyValue = current.getValue(name);
            if(currKeyValue != null && currKeyValue.equals(value))
                return current;
        }

        return null;
    }

    public synchronized void remove(Attribute key)
    {
        remove(key.getName(), key.getValue());
    }

    public synchronized void remove(String key, String value)
    {
        Record toRemove = find(key, value);
        if(toRemove != null)
            records.remove(toRemove);
    }

    public int count()
    {
        return records.size();
    }

    public Record get(int i)
    {
        return (Record)records.get(i);
    }

    public synchronized void read(String fileName)
        throws FileNotFoundException, IOException
    {
        FileInputStream is = new FileInputStream(fileName);
        records = new LinkedList();
        read(((InputStream) (is)));
        is.close();
    }

    public synchronized void read(InputStream is)
        throws IOException
    {
        TableParser parser = getParser();
        parser.parse(is);
    }

    public synchronized void reload()
        throws IOException
    {
        read(fileName);
    }

    public synchronized void write(String fileName)
        throws FileNotFoundException, IOException
    {
        FileOutputStream os = new FileOutputStream(fileName);
        write(((OutputStream) (os)));
        os.close();
    }

    public synchronized void write(OutputStream os)
        throws IOException
    {
        TableParser parser = getParser();
        parser.compose(os);
    }

    public TableParser getParser()
    {
        return new BasicTableParser(this);
    }

    private List records;
    private String fileName;
}
