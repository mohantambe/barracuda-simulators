// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3)
// Source File Name:   BasicTableParser.java

package com.logica.smscsim.util;

import com.logica.smpp.SmppObject;
import com.logica.smpp.debug.Debug;
import com.logica.smpp.debug.Event;
import java.io.*;

// Referenced classes of package com.logica.smscsim.util:
//            Record, TableParser, Table, Attribute

public class BasicTableParser
    implements TableParser
{

    public BasicTableParser(Table table)
    {
        pendingChar = false;
        line = "";
        pendingRecord = false;
        debug = SmppObject.getDebug();
        event = SmppObject.getEvent();
        this.table = table;
    }

    public void parse(InputStream is)
        throws IOException
    {
        //debug.write("going to parse from input stream");
        in = new InputStreamReader(is);
        prepareRecord();
        while(!eof())
        {
            getLine();
            if(isEmpty())
            {
                //debug.write("got empty line");
                finaliseRecord(true);
            } else
            if(!isComment())
                parseAttribute(line);
            else{
                //debug.write("got comment line " + line);
            }
        }
        finaliseRecord(false);
    }

    public void compose(OutputStream os)
        throws IOException
    {
        out = new OutputStreamWriter(os);
        synchronized(table)
        {
            int recCount = table.count();
            for(int ri = 0; ri < recCount; ri++)
            {
                Record record = table.get(ri);
                synchronized(record)
                {
                    int attrCount = record.count();
                    for(int ai = 0; ai < attrCount; ai++)
                    {
                        Attribute attribute = record.get(ai);
                        synchronized(attribute)
                        {
                            line = attribute.getName() + "=" + attribute.getValue();
                        }
                        out.write(line);
                        out.write("\r\n");
                    }

                }
                if(ri + 1 < recCount)
                    out.write("\r\n");
            }

        }
        out.flush();
    }

    void finaliseRecord(boolean prepareNext)
    {
        if(pendingRecord)
        {
            //debug.write("finished record, adding to table");
            table.add(record);
            pendingRecord = false;
            if(prepareNext)
                prepareRecord();
        }
    }

    void prepareRecord()
    {
        record = new Record();
    }

    void parseAttribute(String attr)
    {
        int attrLen = attr.length();
        int currPos = 0;
        //debug.write("going to parse attribute " + attr);
        for(; currPos < attrLen && "=:".indexOf(attr.charAt(currPos)) == -1; currPos++);
        String name = attr.substring(0, currPos);
        String value = attr.substring(currPos + 1, attrLen);
        record.set(name, value);
        pendingRecord = true;
    }

    boolean eof()
        throws IOException
    {
        return !in.ready();
    }

    boolean eol()
    {
        return c == '\r' || c == '\n';
    }

    boolean isEmpty()
    {
        return line.length() == 0;
    }

    boolean isComment()
    {
        return isEmpty() ? false : "#;".indexOf(line.charAt(0)) != -1;
    }

    void getLine()
        throws IOException
    {
        line = "";
        get();
        do
        {
            if(!eol())
                line += c;
            get();
        } while(!eof() && !eol());
        if(!eof() && c == '\r')
        {
            get();
            if(c != '\n')
                unget();
        }
    }

    void get()
        throws IOException
    {
        if(pendingChar)
        {
            c = pending;
            pendingChar = false;
        } else
        {
            c = (char)in.read();
        }
    }

    void unget()
    {
        pending = c;
        pendingChar = true;
    }

    static final char CR = 13;
    static final char LF = 10;
    static final String LINE_END = "\r\n";
    static final String ATTR_DELIMS = "=:";
    static final String COMMENT_CHARS = "#;";
    Table table;
    InputStreamReader in;
    OutputStreamWriter out;
    char c;
    char pending;
    boolean pendingChar;
    String line;
    Record record;
    boolean pendingRecord;
    private Debug debug;
    private Event event;
}
