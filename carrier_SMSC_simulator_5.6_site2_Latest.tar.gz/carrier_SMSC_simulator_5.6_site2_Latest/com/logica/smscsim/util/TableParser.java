// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TableParser.java

package com.logica.smscsim.util;

import java.io.*;

public interface TableParser
{

    public abstract void compose(OutputStream outputstream)
        throws IOException;

    public abstract void parse(InputStream inputstream)
        throws IOException;
}
