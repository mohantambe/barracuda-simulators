// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Record.java

package com.logica.smscsim.util;

import java.util.*;

// Referenced classes of package com.logica.smscsim.util:
//            Attribute

public class Record
{

    public Record()
    {
        attributes = new LinkedList();
    }

    public synchronized void set(String name, String value)
    {
        com.logica.smscsim.util.Attribute attr = get(name);
        if(attr == null)
        {
            attr = new Attribute(name);
            attributes.add(attr);
        }
        attr.setValue(value);
    }

    public synchronized void add(com.logica.smscsim.util.Attribute attr)
    {
        Attribute existing = get(attr.getName());
        if(existing != null)
            existing.setValue(attr.getValue());
        else
            attributes.add(new Attribute(attr.getName(), attr.getValue()));
    }

    public synchronized Attribute get(String name)
    {
        for(ListIterator iter = attributes.listIterator(0); iter.hasNext();)
        {
            Attribute attr = (Attribute)iter.next();
            if(attr.nameEquals(name))
                return attr;
        }

        return null;
    }

    public synchronized String getValue(String name)
    {
        Attribute attr = get(name);
        if(attr != null)
            return attr.getValue();
        else
            return null;
    }

    public Attribute get(int i)
    {
        return (Attribute)attributes.get(i);
    }

    public int count()
    {
        return attributes.size();
    }

    public synchronized void remove(String name)
    {
        Attribute toRemove = get(name);
        if(toRemove != null)
            attributes.remove(toRemove);
    }

    private List attributes;
}
