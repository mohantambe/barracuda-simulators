package com.logica.smscsim;

import com.logica.smpp.SmppObject;
import com.logica.smpp.debug.Debug;
import com.logica.smpp.pdu.*;
import com.logica.smpp.pdu.tlv.*;
import com.logica.smpp.util.ByteBuffer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Properties;

import com.unimobile.uin.message.*;
import com.unimobile.uin.proto.*;
import com.unimobile.uin.umtpfilequeue.UMTPPackableReceiver;
import com.unimobile.uin.umtpfilequeue.UMTPFileQueueWriter;
import com.unimobile.uin.umtpfilequeue.UMTPFileQueueReader;

public class DeliveryInfoSender implements UMTPPackableReceiver {

	private String strStat = "";
	private String msgId = "";
	private String strErr = "";	
	private LinkedList drRequests = new LinkedList();
	private Properties properties = null;
	private boolean isEnabled = false;
	static String propsFilePath = "./smscsim.cfg";
	private static String messageState;
	private static String userMessageReference;
	private static String networkErrCode;
	private static String esm_class = "4";
	
	{
		try {
			FileInputStream propsFile = new FileInputStream(propsFilePath);
			properties = new Properties();
			properties.load(propsFile);
			isEnabled = Boolean.parseBoolean(properties.getProperty("tlv-enabled-for-optional-params"));
			propsFile.close();
			
		} catch (FileNotFoundException fe) {
			
		} catch(IOException io) {
			
		}
		
	}

    protected static class DeliveryInfoEntry {

        public PDUProcessor processor;
        public SubmitSM submit;
        public int sub;
        public int dlvrd;
        public String stat;
        public String err;
        public String messageId;
        public long submitted;
        
        public DeliveryInfoEntry(PDUProcessor processor, SubmitSM submit, String stat, String err, String messageId) {
            sub = 1;
            dlvrd = 1;
            submitted = System.currentTimeMillis();
            this.processor = processor;
            this.submit = submit;
            this.stat = stat;
            this.err = err;
            this.messageId = messageId;
        }
    }

    public DeliveryInfoSender(int drThredsCounts) {
        dateFormatter = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
        debug = SmppObject.getDebug();
		System.err.println("Starting DRWorkerThreads threads : " + drThredsCounts);
        for (int k = 0 ; k < drThredsCounts ; k++) {
            new DRWorkerThreads().start();
        }
    }

    public void submit(PDUProcessor processor, SubmitSM submitRequest, String messageId) {
    	try {
    		setMsgId(messageId);
    		DeliveryInfoEntry entry = new DeliveryInfoEntry(processor, submitRequest, strStat, strErr, messageId);
    		synchronized (objForSync) {
    			drRequests.add(entry);
    		}
    	} catch (Exception e) {
    		System.err.println(e);
		}
    }
    
    private void writeToDRFileQueue (DeliveryInfoEntry entry) {
    	SubmitSM submit = entry.submit;
    	Message msg = new Message();
    	msg.setSender(new Sender ((submit.getDestAddr()).getAddress()));
    	msg.setRecipient(new Recipient(submit.getSourceAddr().getAddress()));
    	msg.setEsmClass((byte)Integer.parseInt(esm_class));
    	StringBuffer msgBody = new StringBuffer("");
    	msgBody.append("id:").append(entry.messageId).append(" ");
    	msgBody.append("sub:").append(entry.sub).append(" ");
    	msgBody.append("dlvrd:").append(entry.dlvrd).append(" ");
    	msgBody.append("submit date:").append(formatDate(entry.submitted)).append(" ");
    	msgBody.append("done date:").append(formatDate(System.currentTimeMillis())).append(" ");
    	msgBody.append("stat:").append(entry.stat).append(" ");
    	msgBody.append("err:").append(entry.err).append(" ");
        String shortMessage = submit.getShortMessage();
         if(shortMessage == null) {            msgBody.append("text:").append("payload");        }else {        int msgLen = shortMessage.length();        msgBody.append("text:").append(shortMessage.substring(0, msgLen <= 20 ? msgLen : 20));        }
        //int msgLen = shortMessage.length();
        //msgBody.append("text:").append(shortMessage.substring(0, msgLen <= 20 ? msgLen : 20));
        if (!isEnabled) {
        	msg.setBody(new Body(msgBody.toString()));
        }
        msg.setServiceType(submit.getServiceType());
        if (drFileQWriter != null) {
        	display(" Writing the DR message to queue :" + msg);
        	drFileQWriter.WriteToQueue(new CmdSubmit(msg));
        } else {
        	display(" drFileQWriter is null : " + msg);
        }
    }

    public int ReceivePackableObject(Packable objPackable, Object obj) throws Exception {
    	DeliverSM deliver = new DeliverSM();
    	CmdSubmit cmdSubmit = null;
    	if(objPackable instanceof CmdSubmit) {
    		cmdSubmit = (CmdSubmit)objPackable;
    	}
    	Message msg = cmdSubmit.getMessage();    	
        deliver.setSourceAddr(msg.getSender().getPhoneNumber().getNumber());
        deliver.setDestAddr(msg.getRecipient().getPhoneNumber().getNumber());
        deliver.setEsmClass((byte)Integer.parseInt(esm_class));

        deliver.setServiceType(msg.getServiceType());
        
        if ( null != messageState && messageState.length() > 0){
        	deliver.setMessageState((byte) Integer.parseInt(messageState));

		}
        if (null != networkErrCode && networkErrCode.length() > 0) {
			TLVOctets nwErrCodeTLV = new TLVOctets(
					com.logica.smpp.Data.OPT_PAR_NW_ERR_CODE);

			nwErrCodeTLV.setValue(new com.logica.smpp.util.ByteBuffer(
					hex2data(networkErrCode)));
			deliver.setExtraOptional(nwErrCodeTLV);
		}
        if(isEnabled) {
	        if ( null != userMessageReference && userMessageReference.length() > 0){
	        	TLVOctets userMsgRefTLV = new TLVOctets(com.logica.smpp.Data.OPT_PAR_USER_MSG_REF);
				userMsgRefTLV.setValue(new com.logica.smpp.util.ByteBuffer(hex2data(userMessageReference)));
				deliver.setExtraOptional(userMsgRefTLV);
				}
	        
	        if (null != msgId && msgId.length() > 0){
	        	deliver.setReceiptedMessageId(msgId);
				}
		} else {
			
			deliver.setShortMessage(URLDecoder.decode(msg.getBody()
					.getContent()));
		}
        PDUprocessor.serverRequest(deliver);
        display(Thread.currentThread().getName()  + " Deliver Receipt : " + deliver.debugString());
    	return 0;
    }

    private void deliver(DeliveryInfoEntry entry) {
        debug.enter(this, "deliver");
        SubmitSM submit = entry.submit;
        DeliverSM deliver = new DeliverSM();
        deliver.setSourceAddr(submit.getDestAddr());
        deliver.setDestAddr(submit.getSourceAddr());
        deliver.setEsmClass((byte)Integer.parseInt(esm_class));
        StringBuffer msg = new StringBuffer("");
        msg.append("id:").append(entry.messageId).append(" ");
        msg.append("sub:").append(entry.sub).append(" ");
        msg.append("dlvrd:").append(entry.dlvrd).append(" ");
        msg.append("submit date:").append(formatDate(entry.submitted)).append(" ");
        msg.append("done date:").append(formatDate(System.currentTimeMillis())).append(" ");
        msg.append("stat:").append(entry.stat).append(" ");
        msg.append("err:").append(entry.err).append(" ");
    	//msg.append("esm_class:").append(esm_class).append(" ");
        if ( null != messageState && messageState.length() > 0)
        	deliver.setMessageState((byte) Integer.parseInt(messageState));
        
        if ( null != userMessageReference && userMessageReference.length() > 0)
        	deliver.setUserMessageReference((byte) Integer.parseInt(userMessageReference));
        
        if ( null != msgId && msgId.length() > 0)
			try {
				deliver.setReceiptedMessageId(msgId);
			} catch (WrongLengthException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        
        
        if ( null != networkErrCode && networkErrCode.length() > 0)
        	deliver.setNetworkErrorCode(new ByteBuffer(hex2data(networkErrCode)));
        
    	String shortMessage = submit.getShortMessage();
        int msgLen = shortMessage.length();
        msg.append("text:").append(shortMessage.substring(0, msgLen <= 20 ? msgLen : 20));
        try {
//            deliver.setShortMessage(msg.toString());
            deliver.setServiceType(submit.getServiceType());
        } catch (WrongLengthOfStringException wronglengthofstringexception) {
        	wronglengthofstringexception.printStackTrace();
        }        
        entry.processor.serverRequest(deliver);
        display(Thread.currentThread().getName()  + " Deliver Receipt : " + deliver.debugString());
        debug.exit(this);
    }

    private String formatDate(long ms) {
        String s;
        synchronized (dateFormatter) {
            s = dateFormatter.format(new Date(ms));
        }
        return s;
    }
    public String getEsmClass() {
		return this.esm_class;
	}
    public String getDRStatusCode() {
		return this.strErr;
	}
	
	public String getDRStatus() {
		return this.strStat;
	}
	
	public void stopDRWorkerThreads() {
		keepAlive = false;
	}
	
	public void setDRStatusCode(String errorCode) {
		this.strErr = errorCode;
	}
	
	public void setDRStatus(String status) {
		this.strStat = status;
	}
	
	public void setMessageState(String messageState) {
		this.messageState = messageState;
	}
	
	public void setNetworkErrCode(String networkErrCode) {
		this.networkErrCode = networkErrCode;
	}
	
	public void setUserMessageReference(String userMessageReference) {
		this.userMessageReference = userMessageReference;
	}
	public void setReceiptedMessageId (String msgId) {
		this.msgId = msgId;
	}
	public void setEsmClass(String esm_class) {
		this.esm_class = esm_class;
	}
	
    public void display(String s) {
    	long timestamp1 = System.currentTimeMillis();
        System.err.println((new Timestamp(timestamp1)).toString() + " [pavel] " + s);
    }
    
    public void setFileQueueDir(String fileQueueDir) {
    	this.fileQueueDir = fileQueueDir;
    }
    
    public void setFileQueueUniqueID(String strUniqueID) {
    	this.uniqueID = strUniqueID;
    }
    
    public void setCommitMsgCount (int commitMsgCount) {
    	this.commitMsgCount = commitMsgCount;
    }
    
    public void setCommitMsgTimeout (int commitMsgTimeout) {
    	this.commitMsgTimeout = commitMsgTimeout;
    }
    
    public void setDRFileExt (String fileExt) {
    	this.drFileExt = fileExt;
    }
    
    public void setDispatcherThreadCount(int dispatcherThreadCount) {
    	this.dispatcherThreadCount = dispatcherThreadCount;
    }
    public void setSleepTimeInterval(int sleepTimeInterval) {
    	this.sleepTimeInterval = sleepTimeInterval;
    }
    
    public void setFileReaderUniqueId (String fileReaderUniqueId) {
    	this.fileReaderUniqueId = fileReaderUniqueId;
    }
    
    public void createDRFileWriter() {
    	try {
    		display(" Creating UMTPFileQueueWriter with details : fileQueueDir:" + fileQueueDir + " uniqueID:" + uniqueID + " commitMsgCount:" + commitMsgCount + " commitMsgTimeout:" + commitMsgTimeout + " drFileExt:" + drFileExt);
    		drFileQWriter = new UMTPFileQueueWriter(fileQueueDir, uniqueID, commitMsgCount, commitMsgTimeout, drFileExt);
    	} catch (Exception e) {
		}
    }
    
    public void createDRFileReader(PDUProcessor PDUprocessor) {
    	this.PDUprocessor = PDUprocessor;
    	try {
    		display(" Creating UMTPFileQueueReader with details : fileQueueDir:" + fileQueueDir + " fileReaderUniqueId:" + fileReaderUniqueId + " sleepTimeInterval:" + sleepTimeInterval + " dispatcherThreadCount:" + dispatcherThreadCount + " drFileExt:" + drFileExt);
    		drFileQReader = new UMTPFileQueueReader(fileQueueDir, this, dispatcherThreadCount, null, drFileExt, fileReaderUniqueId, sleepTimeInterval);    		
    	} catch (Exception e) {
		}
	}

    public void setUseFileQueueWriterForDR(boolean useFileQueueWriterForDR) {
    	this.useFileQueueWriterForDR = useFileQueueWriterForDR;
    }

    public static final int DELIVERED = 0;
    public static final int EXPIRED = 1;
    public static final int DELETED = 2;
    public static final int UNDELIVERABLE = 3;
    public static final int ACCEPTED = 4;
    public static final int UNKNOWN = 5;
    public static final int REJECTED = 6;
    private SimpleDateFormat dateFormatter;
    private Debug debug;
    private Object objForSync = new Object();
    private boolean keepAlive = true;
    private static UMTPFileQueueWriter drFileQWriter = null;
    private static UMTPFileQueueReader drFileQReader = null;    
    private String fileQueueDir = null;
    private String uniqueID = null;
    private int commitMsgCount;
    private int commitMsgTimeout;
    private String drFileExt = null;
    private int dispatcherThreadCount;
    private String fileReaderUniqueId = null;
    private int sleepTimeInterval;
    private PDUProcessor PDUprocessor;
    private boolean useFileQueueWriterForDR;
    
	private class DRWorkerThreads extends Thread {
		public void run() {
            while (keepAlive) {
                try {
                    if (drRequests.size() > 0 ) {                    	
                        synchronized (objForSync) {
                            if (drRequests.size() > 0 ) {
                            	DeliveryInfoEntry deliverInfoEntry = null;
                            	deliverInfoEntry = (DeliveryInfoEntry)drRequests.removeFirst();
                                if (deliverInfoEntry != null) {                                	
                                	long timeStamp = System.currentTimeMillis();
                                	if (useFileQueueWriterForDR) {
                                		writeToDRFileQueue(deliverInfoEntry);
                                	} else {
                                		deliver(deliverInfoEntry);
                                	}
                            		display(Thread.currentThread().getName() + " Time taken to process the Deliver Receipt: " + (System.currentTimeMillis() - timeStamp));
                            	} else {
                            		display(Thread.currentThread().getName() + " deliverInfoEntry is null ");
                            	}
                            }
                        }
                    } else {
                    	Thread.sleep(500);
                    }
                } catch (Exception ex) {
                    display(Thread.currentThread().getName() + " Exception while generating DR : " + ex.toString());
                    ex.printStackTrace(System.err);
                }
			}
		}
	}
	
	public static byte[] hex2data(String str){
		if (str == null)
			return new byte[0] ;

		int len = str.length();    // probably should check length
		char hex[] = str.toCharArray();
		byte[] buf = new byte[len/2];

		for (int pos = 0; pos < len / 2; pos++)
			buf[pos] = (byte)( ((toDataNibble(hex[2*pos]) << 4) & 0xF0)
							   | ( toDataNibble(hex[2*pos + 1])   & 0x0F) );

		return buf;
	}

	public static byte toDataNibble(char c){
		if (('0' <= c) && (c <= '9' ))
			return (byte)((byte)c - (byte)'0');
		else if (('a' <= c) && (c <= 'f' ))
			return (byte)((byte)c - (byte)'a' + 10);
		else if (('A' <= c) && (c <= 'F' ))
			return (byte)((byte)c - (byte)'A' + 10);
		else
			return -1;
	}

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
}
