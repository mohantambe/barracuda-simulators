package com.logica.smscsim;

public interface PDUProcessorFactory {
    public abstract PDUProcessor createPDUProcessor(SMSCSession smscsession);
}