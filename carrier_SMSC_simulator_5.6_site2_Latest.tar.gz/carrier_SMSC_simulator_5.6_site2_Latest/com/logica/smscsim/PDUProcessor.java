package com.logica.smscsim;

import com.logica.smpp.pdu.Request;
import com.logica.smpp.pdu.Response;

public abstract class PDUProcessor {

    public PDUProcessor() {
        group = null;
        active = true;
    }

    public PDUProcessor(PDUProcessorGroup group) {
        this.group = null;
        active = true;
        setGroup(group);
    }

    public abstract void clientRequest(Request request);

    public abstract void clientResponse(Response response);

    public abstract void serverRequest(Request request);
    
    public abstract void display(String str);

    public abstract void serverResponse(Response response);
    
    public abstract void setCommandStatus(int commandStatus); 
    
    public abstract void setUseFileQueueWriterForDR(boolean useFileQueueWriterForDR);

    public abstract void setUseFileQueueReaderForDR(boolean useFileQueueReaderForDR);


    public void setGroup(PDUProcessorGroup g) {
        if(group != null)
            group.remove(this);
        group = g;
        if(group != null)
            group.add(this);
    }

    public PDUProcessorGroup getGroup() {
        return group;
    }

    public boolean isActive() {
        return active;
    }

    protected void exit() {
        if(group != null)
            group.remove(this);
        active = false;
    }
    private PDUProcessorGroup group;
    private boolean active;
}