package com.logica.smscsim;

import com.logica.smpp.*;
import com.logica.smpp.pdu.*;
import java.io.IOException;
import java.sql.Timestamp;

public class SMSCSession extends SmppObject implements Runnable {

    public SMSCSession(Connection connection) {
        receiveTimeout = 60000L;
        keepReceiving = true;        
        this.connection = connection;
        transmitter = new Transmitter(connection);
        receiver = new Receiver(transmitter, connection);
    }

    public void stop() {
        SmppObject.debug.write("SMSCSession stopping");
        keepReceiving = false;
    }

    public void run() {
        PDU pdu = null;
        SmppObject.debug.enter(this, "SMSCSession run()");
        SmppObject.debug.write("SMSCSession starting receiver");
        receiver.start();
        pduProcessor.setUseFileQueueWriterForDR(useFileQueueWriterForDR);
        pduProcessor.setUseFileQueueReaderForDR(useFileQueueReaderForDR);
        try {
            while (keepReceiving) {
                try {
                    pdu = receiver.receive(getReceiveTimeout());
		  	System.err.println("PDU received: "+pdu);
                } catch(Exception e) {
                    SmppObject.debug.write("SMSCSession caught exception receiving PDU " + e.getMessage());
			e.printStackTrace(System.err);
                }
                if(pdu != null) {
                    if(pdu.isRequest()) {
                    	long timeStamp = System.currentTimeMillis();
                        pduProcessor.clientRequest((Request)pdu);
                        System.err.println((new Timestamp(System.currentTimeMillis())).toString() + " [pavel] " + Thread.currentThread().getName() + " Time taken to process the client request : " + (System.currentTimeMillis() - timeStamp));
                    } else if (pdu.isResponse()) {
                        pduProcessor.clientResponse((Response)pdu);
                    }
                }
            }
        } catch (Exception e) {
        	e.printStackTrace(System.err);
        }
        SmppObject.debug.write("SMSCSession stopping receiver");
        receiver.stop();
        SmppObject.debug.write("SMSCSession exiting PDUProcessor");
        pduProcessor.exit();
        try {
            SmppObject.debug.write("SMSCSession closing connection");
            connection.close();
        } catch (IOException e) {
            SmppObject.event.write(e, "closing SMSCSession's connection.");
        }
        SmppObject.debug.write("SMSCSession exiting run()");
        SmppObject.debug.exit(this);
    }

    public void send(PDU pdu) {
        try {
            transmitter.send(pdu);
        } catch (ValueNotSetException e) {
            SmppObject.event.write(e, "");
            System.err.println(e);
        } catch (IOException e) {
            SmppObject.event.write(e, "");
            System.err.println(e);
        } catch (Exception e) {
        	System.err.println(e);
        }
    }

    public void setPDUProcessor(PDUProcessor pduProcessor) {
        this.pduProcessor = pduProcessor;
    }

    public void setReceiveTimeout(long timeout) {
        receiveTimeout = timeout;
    }
    
    public void setUseFileQueueWriterForDR(boolean useFileQueueWriterForDR) {
    	this.useFileQueueWriterForDR = useFileQueueWriterForDR;
    }

    public void setUseFileQueueReaderForDR(boolean useFileQueueReaderForDR) {
    	this.useFileQueueReaderForDR = useFileQueueReaderForDR;
    }


    public long getReceiveTimeout() {
        return receiveTimeout;
    }

    private Receiver receiver;
    private Transmitter transmitter;
    private PDUProcessor pduProcessor;
    private Connection connection;
    private long receiveTimeout;
    private boolean keepReceiving;
    private boolean useFileQueueWriterForDR;
    private boolean useFileQueueReaderForDR;
}
