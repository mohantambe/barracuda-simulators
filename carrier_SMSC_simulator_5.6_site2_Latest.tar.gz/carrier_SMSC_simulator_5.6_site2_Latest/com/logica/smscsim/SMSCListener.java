package com.logica.smscsim;

import com.logica.smpp.*;
import java.io.IOException;
import java.io.InterruptedIOException;

public class SMSCListener extends SmppObject implements Runnable {

    public SMSCListener(int i) {
        serverConn = null;
        acceptTimeout = 5000L;
        processorFactory = null;
        keepReceiving = true;
        isReceiving = false;
        asynchronous = false;
        port = i;
    }

    public SMSCListener(int port, boolean flag, boolean isSSL) {
    	this.serverConn = null;
        this.acceptTimeout = 5000L;
        this.processorFactory = null;
        this.keepReceiving = true;
        this.isReceiving = false;
        this.asynchronous = false;
        this.port = port;
        this.asynchronous = flag;
        this.isSSL = isSSL;
    }

    public synchronized void start() throws IOException {
        debug.write("going to start SMSCListener on port " + port);
        try {
	        if(!isReceiving) {
	        	if (isSSL) {
	        		serverConn = new TCPIPSSLConnection(port, isSSL);
	        	} else {
	        		serverConn = new TCPIPConnection(port);
	        	}
	            serverConn.setReceiveTimeout(getAcceptTimeout());
	            serverConn.open();
	            keepReceiving = true;
	            if(asynchronous) {
	                debug.write("starting listener in separate thread.");
	                Thread thread = new Thread(this);
	                thread.start();
	                debug.write("listener started in separate thread.");
	            } else {
	                debug.write("going to listen in the context of current thread.");
	                run();
	            }
	        } else {
	            debug.write("already receiving, not starting the listener.");
	        }
        } catch (Exception e) {
        	e.printStackTrace(System.err);
		}
    }

    public synchronized void stop() throws IOException {
    	try {
	        debug.write("going to stop SMSCListener on port " + port);
	        keepReceiving = false;
	        while(isReceiving)
	            Thread.yield();
	        serverConn.close();
	        debug.write("SMSCListener stopped on port " + port);
    	} catch (Exception e) {
    		e.printStackTrace(System.err);
		}
    }

    public void run() {
    	try {
	        debug.enter(this, "run of SMSCListener on port " + port);
	        isReceiving = true;
	        while(keepReceiving) {
	            listen();
	            Thread.yield();
	        }
	        isReceiving = false;
	        isReceiving = false;
	        debug.exit(this);
    	} catch (Exception e) {
    		e.printStackTrace(System.err);
		}
        return;        
    }

    private void listen() {
        debug.enter(18, this, "SMSCListener listening on port " + port);
        try {
            Connection connection = null;
            connection = serverConn.accept();
            if(connection != null) {
                debug.write("SMSCListener accepted a connection on port " + port);
                SMSCSession smscsession = new SMSCSession(connection);
                smscsession.setUseFileQueueWriterForDR(useFileQueueWriterForDR);
                smscsession.setUseFileQueueReaderForDR(useFileQueueReaderForDR);
                PDUProcessor pduprocessor = null;
                if(processorFactory != null) {
                    pduprocessor = processorFactory.createPDUProcessor(smscsession);
                    pduprocessor.setUseFileQueueWriterForDR(useFileQueueWriterForDR);
                    pduprocessor.setUseFileQueueReaderForDR(useFileQueueReaderForDR);
                    pduprocessor.setCommandStatus(commandStatus);
                }
                smscsession.setPDUProcessor(pduprocessor);                
                Thread thread = new Thread(smscsession);
                thread.start();
                debug.write("SMSCListener launched a session on the accepted connection.");
            } else {
                debug.write(18, "no connection accepted this time.");
            }
        } catch (InterruptedIOException interruptedioexception) {
            System.err.println(interruptedioexception);
        } catch (IOException ioexception) {
            event.write(ioexception, "IOException accepting connection");
            keepReceiving = false;
            System.err.println(ioexception);
        } catch (Exception e) {
        	e.printStackTrace(System.err);
        }
        debug.exit(18, this);
    }

    public void setPDUProcessorFactory(PDUProcessorFactory pduprocessorfactory) {
        processorFactory = pduprocessorfactory;
    }

    public void setAcceptTimeout(int i) {
        acceptTimeout = i;
    }

    public long getAcceptTimeout() {
        return acceptTimeout;
    }
    
    public void setCommandStatus (int commandStatus) {
    	this.commandStatus = commandStatus;
    }

    public void setUseFileQueueWriterForDR(boolean useFileQueueWriterForDR) {
    	this.useFileQueueWriterForDR = useFileQueueWriterForDR;
    }

    public void setUseFileQueueReaderForDR(boolean useFileQueueReaderForDR) {
    	this.useFileQueueReaderForDR = useFileQueueReaderForDR;
    }

    private Connection serverConn;
    private int port;
    private long acceptTimeout;
    private PDUProcessorFactory processorFactory;
    private boolean keepReceiving;
    private boolean isReceiving;
    private boolean asynchronous;
    private boolean useFileQueueWriterForDR;
    private boolean useFileQueueReaderForDR;
    private boolean isSSL;
    private int commandStatus = 0;
}