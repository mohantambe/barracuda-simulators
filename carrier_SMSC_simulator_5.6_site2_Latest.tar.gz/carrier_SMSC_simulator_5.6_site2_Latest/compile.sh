echo "compile/package start"
/imn/3rdparty/jdk1.8.0_101/bin/javac -classpath ./uinumtpfilequeue.jar:./uinproto_smpp.jar:./uinmsg.jar:./uincfg.jar:./uinlog.jar:./uinproto.jar com/logica/smscsim/util/*.java com/logica/smscsim/*.java
/imn/3rdparty/jdk1.8.0_101/bin/jar -cvf smscsim.jar com
echo "compile/package done"
